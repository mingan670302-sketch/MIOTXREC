"""Regenerate all readable date exports from the canonical SQLite database."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import server

server.initialize()
with server.connect() as db:
    ids = [r[0] for r in db.execute('SELECT id FROM trades ORDER BY id')]
for trade_id in ids:
    server.export_trade(trade_id)
print(f'Rebuilt {len(ids)} records.')
