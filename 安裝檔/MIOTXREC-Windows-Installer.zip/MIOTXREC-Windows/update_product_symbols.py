"""Refresh the offline Taiwan security autocomplete list from official APIs."""
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / 'web' / 'product-symbols.json'
SOURCES = {
    'twse_companies': 'https://openapi.twse.com.tw/v1/opendata/t187ap03_L',
    'tpex_companies': 'https://www.tpex.org.tw/openapi/v1/mopsfin_t187ap03_O',
    'twse_quotes': 'https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL',
    'tpex_quotes': 'https://www.tpex.org.tw/openapi/v1/tpex_mainboard_daily_close_quotes',
}


def fetch(url):
    request = Request(url, headers={'User-Agent': 'LocalTradingJournal/1.0'})
    with urlopen(request, timeout=45) as response:
        return json.load(response)


def clean(value):
    return str(value or '').replace('\u3000', ' ').strip()


def main():
    symbols = {}

    def add(code, name, market, kind='stock'):
        code, name = clean(code).upper(), clean(name)
        if re.fullmatch(r'[0-9A-Z]{2,6}', code) and name:
            symbols[code] = {'code': code, 'name': name, 'market': market, 'kind': kind}

    for row in fetch(SOURCES['twse_companies']):
        add(row.get('公司代號'), row.get('公司簡稱'), '上市')
    for row in fetch(SOURCES['tpex_companies']):
        add(row.get('SecuritiesCompanyCode'), row.get('CompanyAbbreviation'), '上櫃')

    # Add exchange-traded funds while avoiding the much larger warrant universe.
    for row in fetch(SOURCES['twse_quotes']):
        if clean(row.get('Code')).startswith('00'):
            add(row.get('Code'), row.get('Name'), '上市 ETF', 'etf')
    for row in fetch(SOURCES['tpex_quotes']):
        if clean(row.get('SecuritiesCompanyCode')).startswith('00'):
            add(row.get('SecuritiesCompanyCode'), row.get('CompanyName'), '上櫃 ETF', 'etf')

    futures = [
        {'code': 'TX', 'name': '大台（臺股期貨）', 'market': '期貨', 'kind': 'future', 'aliases': ['大台', '臺股期貨', '台指期']},
        {'code': 'MTX', 'name': '小台（小型臺指期貨）', 'market': '期貨', 'kind': 'future', 'aliases': ['小台', '小型臺指']},
        {'code': 'TMF', 'name': '微台（微型臺指期貨）', 'market': '期貨', 'kind': 'future', 'aliases': ['微台', '微型臺指']},
    ]
    items = futures + sorted(symbols.values(), key=lambda item: (item['code'], item['name']))
    payload = {
        'updated_at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
        'sources': list(SOURCES.values()),
        'items': items,
    }
    OUTPUT.write_text(json.dumps(payload, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    print(f'Wrote {len(items)} product symbols to {OUTPUT}')


if __name__ == '__main__':
    main()
