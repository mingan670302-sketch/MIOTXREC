"""Local-only trading journal. Python standard library, no external packages."""
import argparse
import base64
import hashlib
import hmac
import html
import json
import logging
import math
import os
from pathlib import Path
import re
import secrets
import sys
import sqlite3
import tempfile
import threading
from contextlib import closing
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'vendor'))
from pdf_export import render_pdf
SCHEMA = json.loads((ROOT / 'schema.json').read_text(encoding='utf-8'))
FIELDS = {f['key']: f for s in SCHEMA for f in s['fields']}
SLOTS = {'entry': '進場', 'exit': '出場', 'review': '事後複盤'}
TZ = timezone(timedelta(hours=8))
MAX_IMAGE = 10 * 1024 * 1024
MAX_BODY = 43 * 1024 * 1024
LOCK = threading.RLock()
TOKEN = secrets.token_urlsafe(32)
DATA = ROOT / '資料'

def now():
    return datetime.now(TZ).isoformat(timespec='seconds')

class ClosingConnection(sqlite3.Connection):
    def __exit__(self, *args):
        try:
            return super().__exit__(*args)
        finally:
            self.close()

def connect():
    db = sqlite3.connect(DATA / '交易紀錄.sqlite3', timeout=30, factory=ClosingConnection)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA synchronous=FULL')
    return db

def initialize():
    DATA.mkdir(parents=True, exist_ok=True)
    with connect() as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.executescript('''
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS trades (
          id INTEGER PRIMARY KEY AUTOINCREMENT, request_key TEXT NOT NULL UNIQUE,
          trade_date TEXT NOT NULL, product TEXT NOT NULL, payload TEXT NOT NULL,
          started_at TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          duration_seconds INTEGER NOT NULL, revision INTEGER NOT NULL DEFAULT 1,
          exported_date TEXT, export_pending INTEGER NOT NULL DEFAULT 1);
        CREATE INDEX IF NOT EXISTS idx_trades_date ON trades(trade_date DESC,id DESC);
        CREATE TABLE IF NOT EXISTS images (
          trade_id INTEGER NOT NULL REFERENCES trades(id), slot TEXT NOT NULL,
          name TEXT NOT NULL, mime TEXT NOT NULL, data BLOB NOT NULL,
          PRIMARY KEY(trade_id,slot));
        ''')
        pending = [r[0] for r in db.execute('SELECT id FROM trades WHERE export_pending=1')]
    for trade_id in pending:
        try:
            export_trade(trade_id)
        except Exception:
            logging.exception('Export repair pending: %s', trade_id)

def serial(trade_id):
    return f'TR-{trade_id:06d}'

def owner_name(db):
    row = db.execute("SELECT value FROM settings WHERE key='owner_name'").fetchone()
    return row[0] if row else ''

def save_profile(body):
    name = body.get('owner_name')
    if not isinstance(name, str) or not name.strip() or len(name.strip()) > 30 or any(ord(c) < 32 for c in name):
        raise ValueError('請輸入 1 至 30 字的姓名。')
    name = name.strip()
    with LOCK:
        with connect() as db:
            db.execute("INSERT INTO settings(key,value) VALUES('owner_name',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (name,))
            db.execute('UPDATE trades SET export_pending=1')
            ids = [r[0] for r in db.execute('SELECT id FROM trades')]
        warning = ''
        for trade_id in ids:
            try:
                export_trade(trade_id)
            except Exception:
                logging.exception('Profile export pending: %s', trade_id)
                warning = '姓名已儲存，部分日期資料夾尚未更新；下次下載 PDF 時會再次更新。'
    return {'owner_name': name, 'warning': warning}

def read_trade(db, trade_id):
    row = db.execute('SELECT * FROM trades WHERE id=?', (trade_id,)).fetchone()
    if row is None:
        raise LookupError('找不到這筆交易。')
    out = dict(row)
    out['data'] = json.loads(out.pop('payload'))
    out.pop('request_key')
    out['serial'] = serial(trade_id)
    out['owner_name'] = owner_name(db)
    out['folder'] = str(DATA / '每日紀錄' / out['trade_date'])
    out['images'] = {r['slot']: {'name': r['name'], 'mime': r['mime'], 'url': f'/api/trades/{trade_id}/images/{r["slot"]}?v={out["revision"]}'} for r in db.execute('SELECT slot,name,mime FROM images WHERE trade_id=?', (trade_id,))}
    return out

def validate_data(raw):
    if not isinstance(raw, dict):
        raise ValueError('表單格式錯誤。')
    data = {}
    for key, field in FIELDS.items():
        value = raw.get(key, [] if field['type'] == 'checkbox' else '')
        if field['type'] == 'checkbox':
            if not isinstance(value, list) or any(v not in field['options'] for v in value):
                raise ValueError(f'{field["label"]}選項無效。')
            data[key] = list(dict.fromkeys(value))
            continue
        if not isinstance(value, (str, int, float)) or isinstance(value, bool):
            raise ValueError(f'{field["label"]}格式錯誤。')
        value = str(value).strip()
        if len(value) > (120 if key == 'product' else 12000):
            raise ValueError(f'{field["label"]}內容太長。')
        if field.get('required') and not value:
            raise ValueError(f'請填寫{field["label"]}。')
        if value and field['type'] == 'radio' and value not in field['options']:
            raise ValueError(f'{field["label"]}選項無效。')
        if value and field['type'] == 'number':
            try:
                number = float(value)
                if not math.isfinite(number) or abs(number) > 1e15:
                    raise ValueError()
            except (ValueError, OverflowError):
                raise ValueError(f'{field["label"]}必須是有效數字。') from None
        if field['type'] == 'date':
            try:
                if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
                    raise ValueError()
                datetime.strptime(value, '%Y-%m-%d')
            except ValueError:
                raise ValueError('交易日期無效。') from None
        data[key] = value
    return data

def decode_image(value):
    if not isinstance(value, dict) or not isinstance(value.get('content'), str):
        raise ValueError('圖片格式無效。')
    try:
        content = base64.b64decode(value['content'], validate=True)
    except (ValueError, TypeError):
        raise ValueError('圖片內容無法讀取。') from None
    if not content or len(content) > MAX_IMAGE:
        raise ValueError('每張圖片必須小於或等於 10 MB。')
    if content.startswith(b'\x89PNG\r\n\x1a\n'):
        mime = 'image/png'
    elif content.startswith(b'\xff\xd8\xff'):
        mime = 'image/jpeg'
    elif content[:6] in (b'GIF87a', b'GIF89a'):
        mime = 'image/gif'
    elif content[:4] == b'RIFF' and content[8:12] == b'WEBP':
        mime = 'image/webp'
    else:
        raise ValueError('只接受 PNG、JPG、WebP 或 GIF 圖片。')
    name = str(value.get('name', '截圖')).replace('\\', '/').split('/')[-1][:200]
    return name, mime, content

def save_trade(body, trade_id=None):
    data = validate_data(body.get('data'))
    uploads = body.get('images', {})
    if not isinstance(uploads, dict) or any(slot not in SLOTS for slot in uploads):
        raise ValueError('截圖欄位無效。')
    decoded = {slot: None if value is None else decode_image(value) for slot, value in uploads.items()}
    stamp = now()
    with LOCK:
        with connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if trade_id is None:
                key = body.get('request_key', '')
                if not isinstance(key, str) or not re.fullmatch(r'[a-zA-Z0-9-]{16,100}', key):
                    raise ValueError('請重新開啟新增表單。')
                existing = db.execute('SELECT id FROM trades WHERE request_key=?', (key,)).fetchone()
                if existing:
                    return read_trade(db, existing[0])
                started = body.get('started_at', stamp)
                signature = body.get('started_signature', '')
                expected = hmac.new(TOKEN.encode(), str(started).encode(), hashlib.sha256).hexdigest()
                if not isinstance(signature, str) or not hmac.compare_digest(signature, expected):
                    raise ValueError('服務已重新啟動，請重試儲存以更新填表時間。')
                elapsed = max(0, int((datetime.fromisoformat(stamp) - datetime.fromisoformat(started)).total_seconds()))
                trade_id = db.execute('INSERT INTO trades(request_key,trade_date,product,payload,started_at,created_at,updated_at,duration_seconds) VALUES(?,?,?,?,?,?,?,?)', (key, data['trade_date'], data['product'], json.dumps(data, ensure_ascii=False), started, stamp, stamp, elapsed)).lastrowid
            else:
                old = read_trade(db, trade_id)
                if body.get('revision') != old['revision']:
                    raise Conflict('這筆交易已在另一個視窗更新，請重新開啟後再修改。')
                db.execute('UPDATE trades SET trade_date=?,product=?,payload=?,updated_at=?,revision=revision+1,export_pending=1 WHERE id=?', (data['trade_date'], data['product'], json.dumps(data, ensure_ascii=False), stamp, trade_id))
            for slot, image in decoded.items():
                if image is None:
                    db.execute('DELETE FROM images WHERE trade_id=? AND slot=?', (trade_id, slot))
                else:
                    db.execute('INSERT OR REPLACE INTO images(trade_id,slot,name,mime,data) VALUES(?,?,?,?,?)', (trade_id, slot, *image))
        warning = None
        try:
            export_trade(trade_id)
        except Exception:
            logging.exception('Daily export failed')
            warning = '已存入資料庫，但日期資料夾暫時無法寫入；下次啟動會自動補存。'
        with connect() as db:
            result = read_trade(db, trade_id)
        if warning:
            result['warning'] = warning
        return result

class Conflict(Exception):
    pass

def display(value):
    if isinstance(value, list):
        value = '、'.join(value)
    return html.escape(str(value or '未填寫'))

def standalone(record, images):
    sections = ''
    for index, section in enumerate(SCHEMA, 1):
        fields = ''.join(f'<div class="field"><dt>{f["label"]}</dt><dd>{display(record["data"].get(f["key"]))}</dd></div>' for f in section['fields'])
        sections += f'<section><h2>{index:02d}　{section["title"]}</h2><dl>{fields}</dl></section>'
    shots = ''
    for slot, label in SLOTS.items():
        img = images.get(slot)
        content = f'<img alt="{label}截圖" src="data:{img["mime"]};base64,{base64.b64encode(img["data"]).decode()}"><figcaption>{html.escape(img["name"])}</figcaption>' if img else '<p>未上傳</p>'
        shots += f'<figure><h3>{label}</h3>{content}</figure>'
    return f'''<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{record['serial']} 交易紀錄</title>
    <style>body{{font-family:"Microsoft JhengHei",sans-serif;background:#f1f5f8;color:#203347;margin:0;padding:32px}}main{{max-width:1080px;margin:auto}}header,section{{background:white;padding:28px;margin:20px 0;border-radius:16px}}h1{{margin:10px 0}}h2{{color:#087e8b;font-size:20px}}p,dt{{color:#627386}}dl{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}}dd{{margin:8px 0;white-space:pre-wrap;overflow-wrap:anywhere}}img{{max-width:100%;height:auto}}figure{{margin:28px 0}}small{{color:#087e8b}}@media(max-width:600px){{body{{padding:12px}}dl{{grid-template-columns:1fr}}}}@media print{{body{{padding:0;background:white}}section{{break-inside:avoid}}}}</style>
    <main><header><small>TRADING JOURNAL · {record['serial']}</small><h1>{html.escape(record['product'])}</h1><p>交易日期 {record['trade_date']}　｜　{display(record['data']['direction'])}</p><p>開始填表：{record['started_at']}<br>首次儲存：{record['created_at']}<br>最後更新：{record['updated_at']}<br>首次填表耗時：{record['duration_seconds']} 秒</p></header>{sections}<section><h2>07　交易截圖</h2>{shots}</section></main></html>'''

def atomic_write(path, content):
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('wb') as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)

def export_trade(trade_id):
    with LOCK, connect() as db:
        record = read_trade(db, trade_id)
        images = {r['slot']: dict(r) for r in db.execute('SELECT * FROM images WHERE trade_id=?', (trade_id,))}
        folder = DATA / '每日紀錄' / record['trade_date']
        folder.mkdir(parents=True, exist_ok=True)
        prefix = record['serial']
        wanted = {f'{prefix}.html', f'{prefix}.json', f'{prefix}.pdf'}
        manifest = dict(record)
        manifest['images'] = {}
        for slot, img in images.items():
            ext = {'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif'}[img['mime']]
            name = f'{prefix}_{slot}.{ext}'
            wanted.add(name)
            atomic_write(folder / name, img['data'])
            manifest['images'][slot] = {'name': img['name'], 'file': name, 'mime': img['mime']}
        atomic_write(folder / f'{prefix}.html', standalone(record, images).encode('utf-8'))
        atomic_write(folder / f'{prefix}.pdf', render_pdf(record, images))
        atomic_write(folder / f'{prefix}.json', json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8'))
        for stale in folder.glob(f'{prefix}_*'):
            if stale.name not in wanted and stale.is_file():
                stale.unlink()
        old_date = record['exported_date']
        if old_date and old_date != record['trade_date']:
            old_folder = DATA / '每日紀錄' / old_date
            for old in old_folder.glob(f'{prefix}*'):
                if re.fullmatch(re.escape(prefix) + r'(?:\.(?:json|html|pdf)|_(?:entry|exit|review)\.(?:png|jpg|webp|gif))', old.name):
                    old.unlink()
            if old_folder.exists() and not any(old_folder.iterdir()):
                old_folder.rmdir()
        db.execute('UPDATE trades SET exported_date=trade_date,export_pending=0 WHERE id=?', (trade_id,))

class Handler(BaseHTTPRequestHandler):
    server_version = 'TradingJournal/1.0'

    def send(self, status, content, mime='application/json; charset=utf-8', extra=None):
        if not isinstance(content, bytes):
            content = json.dumps(content, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(content)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(content)

    def allowed(self, mutation=False):
        port = self.server.server_port
        hosts = {f'127.0.0.1:{port}', f'localhost:{port}'}
        if self.headers.get('Host') not in hosts:
            return False
        origin = self.headers.get('Origin')
        if origin and origin not in {'http://' + host for host in hosts}:
            return False
        if self.headers.get('Sec-Fetch-Site') == 'cross-site':
            return False
        return not mutation or hmac.compare_digest(self.headers.get('X-Journal-Token', ''), TOKEN)

    def do_GET(self):
        if not self.allowed():
            return self.send(403, {'error': '僅允許本機表單存取。'})
        route = urlparse(self.path)
        try:
            if route.path == '/api/health':
                return self.send(200, {'app': 'local-trading-journal', 'data_dir': str(DATA.resolve())})
            if route.path == '/api/bootstrap':
                stamp = now()
                signature = hmac.new(TOKEN.encode(), stamp.encode(), hashlib.sha256).hexdigest()
                with connect() as db:
                    name = owner_name(db)
                return self.send(200, {'schema': SCHEMA, 'token': TOKEN, 'now': stamp, 'started_signature': signature, 'data_dir': str(DATA), 'today': stamp[:10], 'owner_name': name})
            if route.path == '/api/trades':
                query = parse_qs(route.query)
                day = query.get('date', [''])[0]
                search = query.get('q', [''])[0][:120]
                clauses, params = [], []
                if day:
                    clauses.append('trade_date=?')
                    params.append(day)
                if search:
                    clauses.append("(instr(lower(product),lower(?))>0 OR instr(printf('TR-%06d',id),upper(?))>0)")
                    params += [search, search]
                where = ' WHERE ' + ' AND '.join(clauses) if clauses else ''
                with connect() as db:
                    rows = db.execute('SELECT id,trade_date,product,payload,created_at FROM trades' + where + ' ORDER BY trade_date DESC,id DESC', params).fetchall()
                    items = [{'id': r['id'], 'serial': serial(r['id']), 'trade_date': r['trade_date'], 'product': r['product'], 'direction': json.loads(r['payload'])['direction'], 'r_value': json.loads(r['payload'])['r_value'], 'created_at': r['created_at']} for r in rows]
                    dates = [dict(r) for r in db.execute('SELECT trade_date,count(*) AS count FROM trades GROUP BY trade_date ORDER BY trade_date DESC')]
                    total = db.execute('SELECT count(*) FROM trades').fetchone()[0]
                return self.send(200, {'items': items, 'dates': dates, 'total': total})
            match = re.fullmatch(r'/api/trades/(\d+)(?:/(images/(entry|exit|review)|export))?', route.path)
            if match:
                trade_id = int(match[1])
                with connect() as db:
                    record = read_trade(db, trade_id)
                    if match[3]:
                        img = db.execute('SELECT mime,data FROM images WHERE trade_id=? AND slot=?', (trade_id, match[3])).fetchone()
                        if not img:
                            raise LookupError('未上傳圖片。')
                        return self.send(200, img['data'], img['mime'])
                    if match[2] == 'export':
                        with LOCK:
                            export_trade(trade_id)
                            with connect() as latest_db:
                                latest = read_trade(latest_db, trade_id)
                            pdf = (Path(latest['folder']) / f'{latest["serial"]}.pdf').read_bytes()
                        return self.send(200, pdf, 'application/pdf', {'Content-Disposition': f'attachment; filename="{latest["serial"]}.pdf"'})
                return self.send(200, record)
            if route.path == '/api/backup':
                with tempfile.TemporaryDirectory() as temp:
                    backup = Path(temp) / 'backup.sqlite3'
                    with connect() as source, closing(sqlite3.connect(backup)) as target:
                        source.backup(target)
                    return self.send(200, backup.read_bytes(), 'application/octet-stream', {'Content-Disposition': f'attachment; filename="trading-journal-{now()[:10]}.sqlite3"'})
            static = {'/': 'index.html', '/app.js': 'app.js', '/style.css': 'style.css', '/paper-form.css': 'paper-form.css', '/favicon.svg': 'favicon.svg', '/mio-logo.jpg': 'mio-logo.jpg', '/field-help.js': 'field-help.js', '/field-help.css': 'field-help.css', '/product-symbols.json': 'product-symbols.json'}
            if route.path in static:
                path = ROOT / 'web' / static[route.path]
                mime = {'.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.jpg': 'image/jpeg', '.json': 'application/json'}[path.suffix]
                if path.suffix in {'.html', '.js', '.css', '.svg', '.json'}:
                    mime += '; charset=utf-8'
                return self.send(200, path.read_bytes(), mime)
            raise LookupError('找不到頁面。')
        except LookupError as exc:
            self.send(404, {'error': str(exc)})
        except Exception:
            logging.exception('GET failed')
            self.send(500, {'error': '讀取失敗，請稍後重試。'})

    def do_POST(self):
        if not self.allowed(mutation=True):
            return self.send(403, {'error': '連線已更新，請再次儲存。'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= MAX_BODY:
                return self.send(413, {'error': '上傳內容太大，單張圖片上限 10 MB。'})
            if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                raise ValueError('請使用表單儲存。')
            body = json.loads(self.rfile.read(size))
            if not isinstance(body, dict):
                raise ValueError('表單格式錯誤。')
            path = urlparse(self.path).path
            if path == '/api/profile':
                return self.send(200, save_profile(body))
            if path == '/api/trades':
                return self.send(201, save_trade(body))
            match = re.fullmatch(r'/api/trades/(\d+)', path)
            if match:
                return self.send(200, save_trade(body, int(match[1])))
            raise LookupError('找不到頁面。')
        except Conflict as exc:
            self.send(409, {'error': str(exc)})
        except (ValueError, TypeError) as exc:
            self.send(400, {'error': str(exc)})
        except LookupError as exc:
            self.send(404, {'error': str(exc)})
        except Exception:
            logging.exception('Save failed')
            self.send(500, {'error': '儲存失敗。表單內容已保留，請確認磁碟空間後重試。'})

def main():
    global DATA
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=33968)
    parser.add_argument('--data-dir', type=Path)
    args = parser.parse_args()
    if args.data_dir:
        DATA = args.data_dir.resolve()
    initialize()
    logging.basicConfig(filename=DATA / '服務.log', encoding='utf-8', level=logging.WARNING)
    server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    print(f'http://127.0.0.1:{args.port}', flush=True)
    server.serve_forever()

if __name__ == '__main__':
    main()
