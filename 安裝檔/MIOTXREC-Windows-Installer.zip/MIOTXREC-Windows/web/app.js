'use strict';
const $ = (s, root = document) => root.querySelector(s);
const app = $('#app');
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let boot, schema, formState, dirty = false, saving = false, view = 'new', searchTimer, objectUrls = [], productSymbolsPromise;
const slots = {entry:'進場', exit:'出場', review:'事後複盤'};
const MIO_DAILY_WELCOME_KEY='trading-journal:mio-welcome-date-v1';
const MIO_WELCOME_DISABLED_KEY='trading-journal:mio-welcome-disabled-v1';
let mioWelcomeSeenThisSession=false,profileAfterMioWelcome=false;
let paperResizeObserver;
function fitPaperToWindow(){
  paperResizeObserver?.disconnect();
  const frame=$('.paper-scroll'),paper=$('.journal-paper');
  if(!frame||!paper)return;
  const fit=()=>{
    if(!paper.isConnected){paperResizeObserver.disconnect();return;}
    const style=getComputedStyle(frame);
    const available=frame.clientWidth-parseFloat(style.paddingLeft)-parseFloat(style.paddingRight);
    if(available<=0)return;
    // Keep the PDF table's proportions while fitting the available desktop space.
    const mobile=window.matchMedia('(max-width:760px)').matches;
    const scale=mobile?1:Math.min(1,available/850);
    paper.style.zoom=String(scale);
    paper.style.width=Math.min(1120,Math.max(850,available/scale))+'px';
  };
  paperResizeObserver=new ResizeObserver(fit);
  paperResizeObserver.observe(frame);
  fit();
}
const formatTime = v => v ? new Date(v).toLocaleString('zh-TW',{hour12:false,timeZone:'Asia/Taipei'}) : '—';
function toast(message) { const t=$('#toast'); t.textContent=message;t.hidden=false;clearTimeout(t.timer);t.timer=setTimeout(()=>t.hidden=true,4500); }
async function api(path, options={}) {const response=await fetch(path,options);let data;try{data=await response.json();}catch{throw new Error('無法連線至本機服務，請重新點擊一鍵啟動。');}if(!response.ok){const e=new Error(data.error||'讀取失敗');e.status=response.status;throw e;}return data;}
function error(message) {let box=$('#error');if(!box){box=document.createElement('div');box.id='error';box.className='error';box.setAttribute('role','alert');app.prepend(box);}box.textContent=message;box.scrollIntoView({behavior:'smooth',block:'center'});}
function heading(title,subtitle,actions=''){return `<div class="page-heading"><div><div class="eyebrow">TRADING JOURNAL</div><h1>${title}</h1><p class="subtitle">${subtitle}</p></div>${actions}</div>`;}
function nav(mode){view=mode;$('#nav-new').classList.toggle('active',mode==='new'||mode==='edit');$('#nav-list').classList.toggle('active',mode==='list'||mode==='detail');$('#breadcrumb').textContent={new:'新增交易',edit:'編輯交易',list:'交易紀錄',detail:'交易詳情'}[mode];$('#section-nav').innerHTML=mode==='list'?'':schema.map((s,i)=>`<a href="#section-${i}"><span>0${i+1}</span>${s.title}</a>`).join('')+'<a href="#section-6"><span>07</span>交易截圖</a>';}
function canLeave(){if(saving&&dirty){toast('正在儲存，請稍候。');return false;}return !dirty||confirm('這份表單尚未儲存，確定離開並放棄本次修改？');}
function disposeImages(){objectUrls.forEach(URL.revokeObjectURL);objectUrls=[];}
function fieldHtml(f,data){
  if(f.key==='r_value')return `<div class="field"><label class="field-label" for="f-r_value">損益（R 值） · 自動計算</label><input id="f-r_value" name="r_value" type="number" step="any" readonly aria-describedby="r-help" value="${esc(data.r_value??'')}" placeholder="等待價格資料"><div class="field-note" id="r-help" aria-live="polite"></div></div>`;
  const v=data[f.key]??'';const id='f-'+f.key;const wide=['textarea','checkbox'].includes(f.type)||['timeframe','trend'].includes(f.key);const label=`${esc(f.label)}${f.required?'<span class="required">*</span>':''}`;let input;if(['radio','checkbox'].includes(f.type)){input=`<fieldset><legend>${label}</legend><div class="choices">${f.options.map((o,i)=>`<label class="chip"><input type="${f.type}" name="${f.key}" value="${esc(o)}" ${Array.isArray(v)?(v.includes(o)?'checked':''):(v===o?'checked':'')}><span>${esc(o)}</span></label>`).join('')}</div></fieldset>`;}else{input=`<label class="field-label" for="${id}">${label}</label>`+(f.type==='textarea'?`<textarea id="${id}" name="${f.key}" placeholder="${esc(f.placeholder||'')}" maxlength="12000">${esc(v)}</textarea>`:`<input id="${id}" name="${f.key}" type="${f.type}" ${f.type==='number'?'step="any"':''} ${f.required?'required':''} ${f.key==='product'?'maxlength="120"':''} value="${esc(v)}" placeholder="${esc(f.placeholder||'')}">`);}return `<div class="field ${wide?'wide':''}">${input}${f.hint?`<div class="field-note">${esc(f.hint)}</div>`:''}</div>`;
}
function sectionHeading(i,s){return `<div class="section-heading"><span class="section-number">${String(i+1).padStart(2,'0')}</span><div><h2>${s.title}<small>${s.english}</small></h2><p>${s.hint||''}</p></div></div>`;}

function loadProductSymbols(){
  if(!productSymbolsPromise)productSymbolsPromise=api('/product-symbols.json').then(result=>result.items||[]);
  return productSymbolsPromise;
}
async function attachProductAutocomplete(){
  const input=$('#f-product'),list=$('#product-suggestions'),hint=$('#product-hint');
  if(!input||!list)return;
  try{
    const items=await loadProductSymbols();
    if(!input.isConnected)return;
    const label=item=>`${item.code} ${item.name}`;
    const normalize=value=>value.trim().toLocaleUpperCase('zh-Hant-TW');
    const exact=new Map();
    items.forEach(item=>{
      [item.code,item.name,label(item),...(item.aliases||[])].forEach(alias=>exact.set(normalize(alias),item));
    });
    const render=()=>{
      const query=normalize(input.value);
      const matches=items.filter(item=>{
        if(!query)return item.kind==='future';
        return normalize(item.code).startsWith(query)||normalize(item.name).includes(query)||(item.aliases||[]).some(alias=>normalize(alias).includes(query));
      }).slice(0,60);
      list.innerHTML=matches.map(item=>`<option value="${esc(label(item))}" label="${esc(item.market)}"></option>`).join('');
    };
    const complete=()=>{
      const item=exact.get(normalize(input.value));
      if(item&&input.value!==label(item)){
        input.value=label(item);
        input.dispatchEvent(new Event('input',{bubbles:true}));
      }
    };
    input.addEventListener('input',render);
    input.addEventListener('change',complete);
    input.addEventListener('blur',complete);
    render();
    hint.textContent=`可輸入股票代號或名稱自動完成（本機 ${items.length-3} 筆）；大台 TX｜小台 MTX｜微台 TMF`;
  }catch{
    hint.textContent='大台 TX｜小台 MTX｜微台 TMF；股票清單暫時無法載入，仍可自行輸入商品。';
  }
}

function syncProfile(){
  $('#profile-settings').textContent=boot.owner_name?'姓名：'+boot.owner_name:'設定姓名';
  document.querySelectorAll('.owner-name-display').forEach(el=>{el.textContent=boot.owner_name||'';el.onclick=openProfile;});
}
function openProfile(){
  const exists=Boolean(boot?.owner_name);
  $('#profile-title').textContent=exists?'修改預設姓名':'歡迎使用交易手記';
  $('#owner-name').value=boot?.owner_name||'';
  $('#save-profile').textContent=exists?'儲存姓名':'儲存姓名並開始';
  $('#cancel-profile').hidden=!exists;
  $('#profile-error').hidden=true;
  $('#profile-dialog').showModal();
  $('#owner-name').focus();
}
function shouldShowMioWelcome(){
  if(mioWelcomeSeenThisSession)return false;
  try{return localStorage.getItem(MIO_WELCOME_DISABLED_KEY)!=='true'&&localStorage.getItem(MIO_DAILY_WELCOME_KEY)!==taipeiDateKey();}catch{return true;}
}
function taipeiDateKey(){
  const parts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Taipei',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date()).filter(part=>part.type!=='literal').map(part=>[part.type,part.value]));
  return `${parts.year}-${parts.month}-${parts.day}`;
}
function openMioWelcome(openProfileAfter=false){
  profileAfterMioWelcome=openProfileAfter;
  $('#mio-welcome-hide').checked=false;
  $('#mio-welcome-dialog').showModal();
  $('#mio-welcome-enter').focus();
}
function finishMioWelcome(){
  mioWelcomeSeenThisSession=true;
  try{
    if($('#mio-welcome-hide').checked)localStorage.setItem(MIO_WELCOME_DISABLED_KEY,'true');
    else localStorage.setItem(MIO_DAILY_WELCOME_KEY,taipeiDateKey());
  }catch{}
  $('#mio-welcome-dialog').close();
  if(profileAfterMioWelcome){profileAfterMioWelcome=false;requestAnimationFrame(openProfile);}
}
$('#mio-welcome-close').onclick=finishMioWelcome;
$('#mio-welcome-enter').onclick=finishMioWelcome;
$('#mio-welcome-dialog').addEventListener('cancel',e=>{e.preventDefault();finishMioWelcome();});
$('#profile-settings').onclick=openProfile;
$('#cancel-profile').onclick=()=>$('#profile-dialog').close();
$('#profile-dialog').addEventListener('cancel',e=>{if(!boot?.owner_name||$('#save-profile').disabled)e.preventDefault();});
$('#profile-form').onsubmit=async e=>{
  e.preventDefault();
  const name=$('#owner-name').value.trim();
  if(!name){$('#owner-name').setCustomValidity('請輸入姓名。');$('#owner-name').reportValidity();return;}
  const submit=$('#save-profile');submit.disabled=true;$('#cancel-profile').disabled=true;
  try{
    const result=await api('/api/profile',{method:'POST',headers:{'Content-Type':'application/json','X-Journal-Token':boot.token},body:JSON.stringify({owner_name:name})});
    boot.owner_name=result.owner_name;syncProfile();$('#profile-dialog').close();
    toast(result.warning||'姓名已儲存，下次開啟會自動使用。');
  }catch(err){
    if(err.status===403){try{const fresh=await api('/api/bootstrap');boot.token=fresh.token;}catch{}}
    $('#profile-error').textContent=err.message;$('#profile-error').hidden=false;
  }finally{submit.disabled=false;$('#cancel-profile').disabled=false;}
};
$('#owner-name').oninput=()=>$('#owner-name').setCustomValidity('');

function renderPaperForm(data,record,fresh){
  const fields=Object.fromEntries(schema.flatMap(s=>s.fields).map(f=>[f.key,f]));
  const input=(key,placeholder)=>{
    const f=fields[key],value=data[key]??'';
    const attrs=`id="f-${key}" name="${key}" aria-label="${esc(f.label)}" ${f.required?'required':''} ${key==='product'?'list="product-suggestions" autocomplete="off" aria-describedby="product-hint"':''}`;
    if(f.type==='textarea')return `<textarea ${attrs} rows="1" maxlength="12000" placeholder="${esc(placeholder??f.placeholder??'')}">${esc(value)}</textarea>`;
    return `<input ${attrs} type="${f.type}" ${f.type==='number'?'step="any"':''} ${key==='product'?'maxlength="120"':''} ${key==='r_value'?'readonly aria-describedby="r-help"':''} value="${esc(value)}" placeholder="${esc(placeholder??f.placeholder??'')}">`;
  };
  const choices=(key)=>{
    const f=fields[key],value=data[key]??'';
    return `<div class="paper-choices" role="group" aria-label="${esc(f.label)}">${f.options.map(o=>`<label><input type="${f.type}" name="${key}" value="${esc(o)}" ${(Array.isArray(value)?value.includes(o):value===o)?'checked':''}><span>${esc(o)}</span></label>`).join('')}</div>`;
  };
  const title=(index,label,english)=>`<h2 class="paper-section-title">${label}<small>${english}</small></h2>`;
  const levels=(key)=>`<div class="paper-levels">${[key,key+'_2',key+'_3'].map((k,i)=>`<label><span>${i+1}</span>${input(k,'選填')}</label>`).join('')}</div>`;
  const question=(key,index)=>`<div class="paper-discipline"><span>${['①','②','③','④','⑤','⑥'][index]} ${esc(fields[key].label)}</span>${choices(key)}</div>`;
  const mood=(key)=>`<tr><th scope="row">${fields[key].label}</th>${fields[key].options.map(o=>`<td><label class="paper-mood-option"><input type="radio" name="${key}" value="${esc(o)}" aria-label="${fields[key].label}：${esc(o)}" ${data[key]===o?'checked':''}></label></td>`).join('')}</tr>`;
  const saveLabel=record?'儲存修改':'儲存交易';
  return `<form id="trade-form" class="paper-editor">
    <div class="paper-toolbar"><div><strong>${record?'編輯交易':'新增交易'}</strong><span>${record?esc(record.serial):'流水號於儲存時自動產生'}</span></div><div class="actions"><button type="button" class="secondary" id="go-records">查看交易紀錄</button><button type="submit" class="primary save-button">${saveLabel}</button></div></div>
    <p class="paper-mobile-hint">左右滑動可查看完整表格。</p>
    <div class="paper-scroll" tabindex="0" role="region" aria-label="完整交易記錄表">
    <article class="journal-paper">
      <header class="paper-header"><h1>交易記錄表</h1><div><button type="button" class="owner-name-display" title="點擊修改姓名" aria-haspopup="dialog">${esc(fresh.owner_name||'')}</button>一頁式交易日誌　 Trading Journal　 每筆交易 5 分鐘完成</div></header>
      <div class="paper-meta"><span>${record?esc(record.serial):'新增紀錄'}　${record?'首次填表':'開始填表'}：${formatTime(record?.started_at||fresh.now)}</span><span>填表耗時 <b id="elapsed">00:00</b>　｜　日期 <b id="summary-date">${esc(data.trade_date)}</b></span></div>
      <div class="paper-motto">為什麼進？　　　為什麼出？　　　有沒有遵守自己的規則？</div>
      <section class="paper-section" id="section-0">
        ${title(0,'一、基本資料（客觀事實）','Trade Data')}
        <table class="paper-table paper-basic" aria-label="基本資料"><colgroup>${[12,13,12,13,12,13,12,13].map(w=>`<col style="width:${w}%">`).join('')}</colgroup><tbody>
          <tr><th scope="row"><label for="f-trade_date">日期 <span class="required">*</span></label></th><td colspan="3">${input('trade_date')}</td><th scope="row"><label for="f-product">商品 <span class="required">*</span></label></th><td colspan="3">${input('product')}<datalist id="product-suggestions"></datalist><div class="paper-product-hint" id="product-hint">股票代號或名稱可自動完成；大台 TX｜小台 MTX｜微台 TMF</div></td></tr>
          <tr><th scope="row">買 / 賣</th><td colspan="3">${choices('direction')}</td><th scope="row">時間週期</th><td colspan="3">${choices('timeframe')}</td></tr>
          <tr>${['entry_price','stop_price','exit_price','target_price'].map(k=>`<th scope="row"><label for="f-${k}">${fields[k].label}</label></th><td>${input(k)}</td>`).join('')}</tr>
          <tr><th scope="row"><label for="f-r_value">損益（R 值）</label></th><td colspan="3"><div class="paper-r">${input('r_value','自動換算')}<span>自動計算</span></div></td><th scope="row">按計畫執行</th><td colspan="3">${choices('followed_plan')}</td></tr>
        </tbody></table><div id="r-help" class="paper-note" aria-live="polite"></div>
      </section>
      <section class="paper-section" id="section-1">
        ${title(1,'二、交易計畫（進場前填寫）','Plan')}
        <table class="paper-table" aria-label="交易計畫"><colgroup><col style="width:12%"><col style="width:38%"><col style="width:12%"><col style="width:38%"></colgroup><tbody>
          <tr><th scope="row">市場趨勢</th><td colspan="3">${choices('trend')}</td></tr>
          <tr><th scope="row">關鍵支撐位</th><td>${levels('support')}</td><th scope="row">關鍵壓力位</th><td>${levels('resistance')}</td></tr>
        </tbody></table><p class="paper-note">支撐位與壓力位各可填三個，皆可留白。</p>
      </section>
      <section class="paper-section" id="section-2">
        ${title(2,'三、交易邏輯（最重要）','Logic')}
        <table class="paper-table paper-logic" aria-label="交易邏輯"><colgroup><col style="width:30%"><col style="width:70%"></colgroup><tbody>
          <tr><th colspan="2" scope="row">① 為什麼進場？（可複選）</th></tr><tr><td colspan="2">${choices('entry_reasons')}</td></tr>
          <tr><th scope="row"><label for="f-entry_basis">② 我的進場依據（寫一句話就夠）</label></th><td>${input('entry_basis')}</td></tr>
          <tr><th colspan="2" scope="row">③ 止損依據 <small>（不要寫感覺）</small></th></tr><tr><td colspan="2">${choices('stop_reasons')}</td></tr>
          <tr><th colspan="2" scope="row">④ 出場依據</th></tr><tr><td colspan="2">${choices('exit_reasons')}</td></tr>
          <tr><th scope="row"><label for="f-logic_notes">其它依據補充</label></th><td>${input('logic_notes','選填')}</td></tr>
        </tbody></table>
      </section>
      <section class="paper-section" id="section-3">
        ${title(3,'四、交易紀律（理想狀態：全部勾沒有）','Discipline')}
        <table class="paper-table" aria-label="交易紀律"><tbody>${[['deviated','chased'],['early_entry','moved_stop'],['emotional','overtraded']].map((row,i)=>`<tr>${row.map((k,j)=>`<td>${question(k,i*2+j)}</td>`).join('')}</tr>`).join('')}</tbody></table>
      </section>
      <section class="paper-section" id="section-4">
        ${title(4,'五、心理狀態','Mindset')}
        <table class="paper-table paper-mindset" aria-label="心理狀態"><colgroup><col style="width:14%">${fields.mood_before.options.map(()=>'<col style="width:17.2%">').join('')}</colgroup><thead><tr><th scope="col">時機</th>${fields.mood_before.options.map(o=>`<th scope="col">${esc(o)}</th>`).join('')}</tr></thead><tbody>${mood('mood_before')}${mood('mood_after')}</tbody></table>
        <p class="paper-note">很多虧損都發生在焦慮 / FOMO / 想翻本的時候。不用寫作文，勾選就好。</p>
      </section>
      <section class="paper-section" id="section-5">
        ${title(5,'六、交易反思','Review')}
        <table class="paper-table paper-review" aria-label="交易反思"><colgroup><col style="width:30%"><col style="width:70%"></colgroup><tbody>
          <tr><th scope="row"><label for="f-best">這筆交易做得最好的地方是什麼？</label></th><td>${input('best')}</td></tr>
          <tr><th scope="row"><label for="f-improve">如果重來一次，我會改什麼？</label></th><td>${input('improve')}</td></tr>
          <tr><th scope="row">今天最大的收穫</th><td>${choices('lessons')}</td></tr>
          <tr><th scope="row"><label for="f-lesson_notes">其它收穫補充</label></th><td>${input('lesson_notes','選填')}</td></tr>
        </tbody></table>
      </section>
      <section class="paper-section paper-screenshots" id="section-6">
        ${title(6,'七、截圖（固定三張，使用檔案上傳）','Screenshots')}
        <div class="paper-upload-grid">${Object.entries(slots).map(([k,label],i)=>`<div class="upload" id="upload-${k}"><div class="upload-title">${['①','②','③'][i]}　${label}</div><div id="preview-${k}"></div><label class="paper-upload-control"><span class="upload-plus">＋</span>點選或拖曳圖片<input aria-label="${label}截圖" type="file" data-slot="${k}" accept="image/png,image/jpeg,image/webp,image/gif"></label><div class="tiny">PNG · JPG · WebP · GIF<br>每張上限 10 MB</div></div>`).join('')}</div>
      </section>
      <footer class="paper-footer">交易記錄表（繁體中文版）　｜　僅日期與商品必填，其餘皆可選填。</footer>
    </article></div>
    <div class="paper-savebar"><div><div>填寫進度 <b id="progress-label">0 / 7</b><span class="paper-save-note">儲存後依日期歸檔：<span id="folder-date">${esc(data.trade_date)}</span></span></div><div class="progress-track"><div id="progress-bar"></div></div></div><button type="submit" class="primary save-button">${saveLabel} ↗</button></div>
  </form>`;
}

function renderPaperRecord(r){
  const data=r.data;
  const fields=Object.fromEntries(schema.flatMap(s=>s.fields).map(f=>[f.key,f]));
  const value=(key,empty='—')=>{
    const raw=data[key];
    const text=Array.isArray(raw)?raw.join('、'):raw;
    return `<div class="paper-record-value ${text?'':'paper-record-empty'}">${esc(text||empty)}</div>`;
  };
  const choices=key=>{
    const selected=data[key]??'';
    return `<div class="paper-choices paper-record-choices" role="list" aria-label="${esc(fields[key].label)}">${fields[key].options.map(option=>{
      const active=Array.isArray(selected)?selected.includes(option):selected===option;
      return `<span class="paper-choice ${active?'selected':''}" role="listitem"><span class="paper-check" aria-hidden="true">${active?'✓':''}</span><span>${esc(option)}</span></span>`;
    }).join('')}</div>`;
  };
  const title=(label,english)=>`<h2 class="paper-section-title">${label}<small>${english}</small></h2>`;
  const levels=key=>`<div class="paper-levels paper-record-levels">${[key,key+'_2',key+'_3'].map((item,index)=>`<div><span>${index+1}</span>${value(item)}</div>`).join('')}</div>`;
  const question=(key,index)=>`<div class="paper-discipline"><span>${['①','②','③','④','⑤','⑥'][index]} ${esc(fields[key].label)}</span>${choices(key)}</div>`;
  const mood=key=>`<tr><th scope="row">${esc(fields[key].label)}</th>${fields[key].options.map(option=>`<td><span class="paper-mood-mark ${data[key]===option?'selected':''}" aria-label="${esc(fields[key].label)}：${esc(option)}${data[key]===option?'，已選':''}">${data[key]===option?'✓':''}</span></td>`).join('')}</tr>`;
  const duration=`${Math.floor(r.duration_seconds/60)} 分 ${r.duration_seconds%60} 秒`;
  return `<div class="paper-viewer">
    <div class="paper-toolbar"><div><strong>交易詳情</strong><span>${esc(r.serial)} · ${esc(r.product)}</span></div><div class="actions"><button class="secondary" id="back-list">返回紀錄</button><a class="secondary" href="/api/trades/${r.id}/export">↓ 下載 PDF（原表排版）</a><button class="primary" id="edit-trade">編輯交易</button></div></div>
    <p class="paper-mobile-hint">左右滑動可查看完整表格。</p>
    <div class="paper-scroll" tabindex="0" role="region" aria-label="${esc(r.serial)} 完整交易記錄表">
    <article class="journal-paper paper-record">
      <header class="paper-header"><h1>交易記錄表</h1><div>${r.owner_name?`<span class="paper-owner-name">${esc(r.owner_name)}</span>`:''}一頁式交易日誌　 Trading Journal　 每筆交易 5 分鐘完成</div></header>
      <div class="paper-meta"><span>${esc(r.serial)}　填表：${formatTime(r.started_at)}　儲存：${formatTime(r.created_at)}</span><span>填表耗時 <b>${duration}</b>　｜　日期 <b>${esc(r.trade_date)}</b></span></div>
      <div class="paper-motto">為什麼進？　　　為什麼出？　　　有沒有遵守自己的規則？</div>
      <section class="paper-section" id="section-0">
        ${title('一、基本資料（客觀事實）','Trade Data')}
        <table class="paper-table paper-basic" aria-label="基本資料"><colgroup>${[12,13,12,13,12,13,12,13].map(width=>`<col style="width:${width}%">`).join('')}</colgroup><tbody>
          <tr><th scope="row">日期</th><td colspan="3">${value('trade_date')}</td><th scope="row">商品</th><td colspan="3">${value('product')}</td></tr>
          <tr><th scope="row">買 / 賣</th><td colspan="3">${choices('direction')}</td><th scope="row">時間週期</th><td colspan="3">${choices('timeframe')}</td></tr>
          <tr>${['entry_price','stop_price','exit_price','target_price'].map(key=>`<th scope="row">${esc(fields[key].label)}</th><td>${value(key)}</td>`).join('')}</tr>
          <tr><th scope="row">損益（R 值）</th><td colspan="3">${value('r_value')}</td><th scope="row">按計畫執行</th><td colspan="3">${choices('followed_plan')}</td></tr>
        </tbody></table>
      </section>
      <section class="paper-section" id="section-1">
        ${title('二、交易計畫（進場前填寫）','Plan')}
        <table class="paper-table" aria-label="交易計畫"><colgroup><col style="width:12%"><col style="width:38%"><col style="width:12%"><col style="width:38%"></colgroup><tbody>
          <tr><th scope="row">市場趨勢</th><td colspan="3">${choices('trend')}</td></tr>
          <tr><th scope="row">關鍵支撐位</th><td>${levels('support')}</td><th scope="row">關鍵壓力位</th><td>${levels('resistance')}</td></tr>
        </tbody></table>
      </section>
      <section class="paper-section" id="section-2">
        ${title('三、交易邏輯（最重要）','Logic')}
        <table class="paper-table paper-logic" aria-label="交易邏輯"><colgroup><col style="width:30%"><col style="width:70%"></colgroup><tbody>
          <tr><th colspan="2" scope="row">① 為什麼進場？（可複選）</th></tr><tr><td colspan="2">${choices('entry_reasons')}</td></tr>
          <tr><th scope="row">② 我的進場依據（寫一句話就夠）</th><td>${value('entry_basis')}</td></tr>
          <tr><th colspan="2" scope="row">③ 止損依據 <small>（不要寫感覺）</small></th></tr><tr><td colspan="2">${choices('stop_reasons')}</td></tr>
          <tr><th colspan="2" scope="row">④ 出場依據</th></tr><tr><td colspan="2">${choices('exit_reasons')}</td></tr>
          <tr><th scope="row">其它依據補充</th><td>${value('logic_notes')}</td></tr>
        </tbody></table>
      </section>
      <section class="paper-section" id="section-3">
        ${title('四、交易紀律（理想狀態：全部勾沒有）','Discipline')}
        <table class="paper-table" aria-label="交易紀律"><tbody>${[['deviated','chased'],['early_entry','moved_stop'],['emotional','overtraded']].map((row,rowIndex)=>`<tr>${row.map((key,columnIndex)=>`<td>${question(key,rowIndex*2+columnIndex)}</td>`).join('')}</tr>`).join('')}</tbody></table>
      </section>
      <section class="paper-section" id="section-4">
        ${title('五、心理狀態','Mindset')}
        <table class="paper-table paper-mindset" aria-label="心理狀態"><colgroup><col style="width:14%">${fields.mood_before.options.map(()=>'<col style="width:17.2%">').join('')}</colgroup><thead><tr><th scope="col">時機</th>${fields.mood_before.options.map(option=>`<th scope="col">${esc(option)}</th>`).join('')}</tr></thead><tbody>${mood('mood_before')}${mood('mood_after')}</tbody></table>
        <p class="paper-note">很多虧損都發生在焦慮 / FOMO / 想翻本的時候。不用寫作文，勾選就好。</p>
      </section>
      <section class="paper-section" id="section-5">
        ${title('六、交易反思','Review')}
        <table class="paper-table paper-review" aria-label="交易反思"><colgroup><col style="width:30%"><col style="width:70%"></colgroup><tbody>
          <tr><th scope="row">這筆交易做得最好的地方是什麼？</th><td>${value('best')}</td></tr>
          <tr><th scope="row">如果重來一次，我會改什麼？</th><td>${value('improve')}</td></tr>
          <tr><th scope="row">今天最大的收穫</th><td>${choices('lessons')}</td></tr>
          <tr><th scope="row">其它收穫補充</th><td>${value('lesson_notes')}</td></tr>
        </tbody></table>
      </section>
      <section class="paper-section paper-screenshots" id="section-6">
        ${title('七、截圖（固定三張，點選可放大）','Screenshots')}
        <div class="paper-upload-grid">${Object.entries(slots).map(([key,label],index)=>`<figure class="paper-record-shot"><h3>${['①','②','③'][index]}　${label}</h3>${r.images[key]?`<img src="${esc(r.images[key].url)}" alt="${label}交易截圖" tabindex="0">`:'<div class="paper-record-no-image">未上傳</div>'}</figure>`).join('')}</div>
      </section>
      <footer class="paper-footer">${esc(r.serial)}　更新 ${formatTime(r.updated_at)}　填表耗時 ${duration}<br>交易記錄表（繁體中文版）</footer>
    </article></div>
    <div class="paper-record-actions"><span>日期資料夾：${esc(r.folder)}</span><button class="primary" id="next-trade">＋ 再記一筆</button></div>
  </div>`;
}

async function newForm(record=null){
  if(!canLeave())return;
  let fresh;try{fresh=await api('/api/bootstrap');}catch(e){error(e.message);return;}
  boot=fresh;dirty=false;disposeImages();
  formState={record,request_key:crypto.randomUUID(),started_at:fresh.now,started_signature:fresh.started_signature,images:{},previews:{},pendingUploads:0,uploadVersions:{}};
  const data=record?record.data:{trade_date:fresh.today};
  if(record)Object.entries(record.images).forEach(([k,v])=>formState.previews[k]={url:v.url,name:v.name});
  nav(record?'edit':'new');
  app.innerHTML=renderPaperForm(data,record,fresh);
  window.JournalHelp.attach(schema);
  fitPaperToWindow();
  attachProductAutocomplete();
  const onFormChange=event=>{dirty=true;if(['direction','entry_price','stop_price','exit_price'].includes(event.target.name))calculateR();updateProgress();};
  $('#trade-form').addEventListener('input',onFormChange);$('#trade-form').addEventListener('change',onFormChange);$('#trade-form').addEventListener('submit',saveForm);
  $('#go-records').onclick=()=>showList();
  if(record&&data.r_value!=='')$('#r-help').textContent='已保留原有 R 值；修改方向或價格時自動重算（未含手續費與滑價）。';else calculateR();
  document.querySelectorAll('input[type=file]').forEach(input=>input.onchange=()=>loadFile(input.dataset.slot,input.files[0]));
  Object.keys(slots).forEach(k=>{renderPreview(k);const box=$('#upload-'+k);box.ondragover=e=>{e.preventDefault();box.classList.add('dragging');};box.ondragleave=()=>box.classList.remove('dragging');box.ondrop=e=>{e.preventDefault();box.classList.remove('dragging');loadFile(k,e.dataTransfer.files[0]);};});
  updateProgress();window.scrollTo(0,0);
  syncProfile();if(shouldShowMioWelcome())openMioWelcome(!boot.owner_name);else if(!boot.owner_name)openProfile();
}
function collect(){const form=$('#trade-form');const data={};schema.flatMap(s=>s.fields).forEach(f=>{if(f.type==='checkbox')data[f.key]=[...form.querySelectorAll(`[name="${f.key}"]:checked`)].map(x=>x.value);else if(f.type==='radio')data[f.key]=form.querySelector(`[name="${f.key}"]:checked`)?.value||'';else data[f.key]=form.elements[f.key].value.trim();});return data;}
function updateProgress(){if(!$('#trade-form'))return;const data=collect();const complete=schema.filter(s=>s.fields.some(f=>f.key!=='trade_date'&&(Array.isArray(data[f.key])?data[f.key].length:data[f.key]))).length+(Object.keys(slots).some(k=>formState.previews[k])?1:0);$('#progress-label').textContent=`${complete} / 7`;$('#progress-bar').style.width=(complete/7*100)+'%';$('#summary-date').textContent=data.trade_date||'尚未選擇';$('#folder-date').textContent=data.trade_date||'YYYY-MM-DD';}
function calculateR(){
  const d=collect(),output=$('#f-r_value'),hint=$('#r-help');
  output.value='';
  if(!d.direction||[d.entry_price,d.exit_price,d.stop_price].some(v=>v==='')){hint.textContent='填入交易方向、入場、止損與出場價格後自動換算。';return;}
  const entry=Number(d.entry_price),stop=Number(d.stop_price),exit=Number(d.exit_price);
  if(![entry,stop,exit].every(Number.isFinite)){hint.textContent='請輸入有效價格。';return;}
  const isLong=d.direction==='Long（做多）';
  if((isLong&&stop>=entry)||(!isLong&&stop<=entry)){hint.textContent=isLong?'做多的止損價格須低於入場價格。':'做空的止損價格須高於入場價格。';return;}
  const r=(exit-entry)*(isLong?1:-1)/Math.abs(entry-stop);
  if(!Number.isFinite(r)||Math.abs(r)>1e15){hint.textContent='價格差距無法換算，請確認入場與止損價格。';return;}
  output.value=Number(r.toFixed(4));
  hint.textContent='已自動換算；價格變更時即時更新（未含手續費與滑價）。';
}
async function loadFile(slot,file){if(!file)return;if(file.size>10*1024*1024)return toast('圖片超過 10 MB，請選擇較小的圖片。');if(!['image/png','image/jpeg','image/webp','image/gif'].includes(file.type))return toast('請使用 PNG、JPG、WebP 或 GIF 圖片。');const state=formState;const version=(state.uploadVersions[slot]||0)+1;state.uploadVersions[slot]=version;state.pendingUploads++;const url=URL.createObjectURL(file);try{const img=new Image();img.src=url;await img.decode();if(formState!==state||state.uploadVersions[slot]!==version){URL.revokeObjectURL(url);return;}state.images[slot]=file;state.previews[slot]={url,name:file.name};objectUrls.push(url);dirty=true;renderPreview(slot);updateProgress();}catch{URL.revokeObjectURL(url);toast('無法讀取這張圖片，請換一個檔案。');}finally{state.pendingUploads--;}}
function renderPreview(slot){const target=$('#preview-'+slot);if(!target)return;const p=formState.previews[slot];target.innerHTML=p?`<img src="${esc(p.url)}" alt="${slots[slot]}截圖預覽"><div class="filename">${esc(p.name)}</div><button type="button" class="remove-image">移除圖片</button>`:'';if(p)$('button',target).onclick=()=>{formState.images[slot]=null;delete formState.previews[slot];$(`input[data-slot="${slot}"]`).value='';dirty=true;renderPreview(slot);updateProgress();};}
const fileBase64=file=>new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result.split(',')[1]);reader.onerror=()=>reject(new Error('圖片讀取失敗'));reader.readAsDataURL(file);});
async function saveForm(event){event.preventDefault();if(saving)return;if(formState.pendingUploads)return toast('正在讀取圖片，請稍候再儲存。');if(!$('#trade-form').reportValidity())return;saving=true;document.getElementById('trade-form').inert=true;document.querySelectorAll('.save-button').forEach(b=>{b.disabled=true;b.textContent='正在儲存…';});$('#error')?.remove();try{const uploads={};for(const[k,file]of Object.entries(formState.images))uploads[k]=file?{name:file.name,content:await fileBase64(file)}:null;const body={data:collect(),images:uploads,request_key:formState.request_key,started_at:formState.started_at,started_signature:formState.started_signature,revision:formState.record?.revision};const path=formState.record?`/api/trades/${formState.record.id}`:'/api/trades';const result=await api(path,{method:'POST',headers:{'Content-Type':'application/json','X-Journal-Token':boot.token},body:JSON.stringify(body)});dirty=false;await showDetail(result.id,result.warning||`已儲存 ${result.serial}，資料與截圖已歸檔。`);await updateCount();}catch(e){if(e.status===403){try{boot=await api('/api/bootstrap');formState.started_at=boot.now;formState.started_signature=boot.started_signature;}catch{}}error(e.message);}finally{saving=false;if(document.getElementById('trade-form'))document.getElementById('trade-form').inert=false;document.querySelectorAll('.save-button').forEach(b=>{b.disabled=false;b.textContent=formState.record?'儲存修改':'儲存交易 ↗';});}}
async function updateCount(){const result=await api('/api/trades');$('#record-count').textContent=result.total;return result;}
async function showList(){if(!canLeave())return;try{const result=await updateCount();dirty=false;disposeImages();nav('list');app.innerHTML=heading('交易紀錄','每一筆交易，都保留完整的決策與畫面。','<button class="primary" id="add-trade">＋ 新增交易</button>')+`<div class="filters"><input id="search" type="search" aria-label="搜尋商品或流水號" placeholder="搜尋商品或流水號…"><select id="date-filter" aria-label="依日期篩選"><option value="">所有日期</option>${result.dates.map(d=>`<option value="${d.trade_date}">${d.trade_date}（${d.count} 筆）</option>`).join('')}</select><button class="secondary" id="backup-list">↓ 備份資料庫</button></div><div class="list-meta"><span id="list-count"></span><span>依交易日期歸檔</span></div><div id="records"></div>`;$('#add-trade').onclick=()=>newForm();$('#backup-list').onclick=backup;$('#search').oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(filterList,200);};$('#date-filter').onchange=filterList;renderList(result);window.JournalHelp.attach(schema);window.scrollTo(0,0);}catch(e){error(e.message);}}
let filterVersion=0;
async function filterList(){const n=++filterVersion;try{const q=new URLSearchParams({q:$('#search').value,date:$('#date-filter').value});const result=await api('/api/trades?'+q);if(n===filterVersion&&view==='list')renderList(result);}catch(e){error(e.message);}}
function renderList(result){$('#list-count').textContent=`共 ${result.items.length} 筆紀錄`;let previous='';$('#records').innerHTML=result.items.length?result.items.map(r=>{const group=previous!==r.trade_date?`<h2 class="date-heading">${r.trade_date}<span>日期資料夾</span></h2>`:'';previous=r.trade_date;return group+`<button class="record-row" data-id="${r.id}"><span class="record-id">${r.serial}</span><span class="record-product">${esc(r.product)}</span><span class="record-direction">${esc(r.direction||'未填方向')}</span><span class="record-r ${Number(r.r_value)>0?'positive':Number(r.r_value)<0?'negative':''}">${r.r_value!==''?esc(r.r_value)+' R':'—'}</span><span class="chevron">↗</span></button>`;}).join(''):`<div class="empty"><div class="empty-symbol">▤</div><h2>${result.total?'找不到符合的交易':'從第一筆交易開始'}</h2><p>${result.total?'試試其他商品名稱、流水號或日期。':'填寫一筆交易，讓決策、紀律與反思一起留下來。'}</p>${result.total?'':'<button class="primary" id="first-trade">＋ 新增第一筆交易</button>'}</div>`;document.querySelectorAll('.record-row').forEach(b=>b.onclick=()=>showDetail(b.dataset.id));if($('#first-trade'))$('#first-trade').onclick=()=>newForm();}
async function showDetail(id,message=''){if(!canLeave())return;try{const r=await api('/api/trades/'+id);dirty=false;disposeImages();nav('detail');app.innerHTML=(message?`<div class="saved-note" role="status">${esc(message)}</div>`:'')+renderPaperRecord(r);$('#back-list').onclick=()=>showList();$('#edit-trade').onclick=()=>newForm(r);$('#next-trade').onclick=()=>newForm();document.querySelectorAll('.paper-record-shot img').forEach(img=>{img.onclick=()=>{$('#large-image').src=img.src;$('#image-dialog').showModal();};img.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();img.click();}};});fitPaperToWindow();window.scrollTo(0,0);}catch(e){error(e.message);}}
function backup(){const a=document.createElement('a');a.href='/api/backup';a.download='';a.click();}
$('#nav-new').onclick=()=>newForm();$('#nav-list').onclick=()=>showList();$('.brand').onclick=e=>{e.preventDefault();newForm();};$('#backup').onclick=backup;$('#close-image').onclick=()=>$('#image-dialog').close();$('#image-dialog').onclick=e=>{if(e.target===$('#image-dialog'))$('#image-dialog').close();};
window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
setInterval(()=>{$('#clock').textContent=new Date().toLocaleString('zh-TW',{timeZone:'Asia/Taipei',hour12:false});if($('#elapsed')&&formState){const seconds=Math.max(0,Math.floor((Date.now()-new Date(formState.started_at))/1000));$('#elapsed').textContent=`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;}},1000);
(async()=>{try{boot=await api('/api/bootstrap');schema=boot.schema;await newForm();await updateCount();const mc=document.modelContext;if(mc?.registerTool){const lifecycle=new AbortController();window.addEventListener('pagehide',()=>lifecycle.abort(),{once:true});for(const tool of [{name:'list_trading_records',description:'Read saved local trading records.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:true},execute:async()=>api('/api/trades')},{name:'open_trading_record',description:'Open one saved trading record on the visible page.',inputSchema:{type:'object',properties:{id:{type:'integer',minimum:1}},required:['id'],additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:true},execute:async input=>{if(!Number.isInteger(input?.id)||input.id<1)throw new Error('Invalid record id');if(dirty)throw new Error('Save current edits before navigating');const r=await api('/api/trades/'+input.id);await showDetail(input.id);return{serial:r.serial,opened:true};}}]){try{await mc.registerTool(tool,{signal:lifecycle.signal});}catch{}}}}catch(e){error(e.message);}})();
