/* Local, illustrated field guidance. Examples never change the user's form. */
(() => {
  'use strict';
  const escape = value => String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const entries={};
  const add=(key,title,intro,steps,example,kind,labels)=>entries[key]={title,intro,steps,example,kind,labels};
  add('trade_date','交易日期','這筆交易所屬的日期，也是本機日期資料夾的名稱。',['必填。預設使用台北當日日期，可用日期選擇器補記其他日期。','同一天的交易會歸入同一資料夾；編輯日期後，匯出檔會移到新日期資料夾。','交易日期可修改；開始填表、首次儲存及最後更新時間由系統另外記錄。'],'交易日期填 2026-09-20 → 存入「每日紀錄 / 2026-09-20」。','flow',['選擇日期','儲存交易','同日歸檔']);
  add('product','交易商品','用名稱或代號辨識這筆交易的標的。',['必填，最多 120 字。輸入上市、上櫃股票或 ETF 的代號／名稱會顯示建議，輸入完整代號後離開欄位也會自動帶出名稱。','臺指期貨可輸入大台 TX、小台 MTX、微台 TMF；也可自行填寫 BTC/USDT 等其他商品。','自動完成清單儲存在本機，只協助統一名稱，不會取得報價或送出交易指令。'],'輸入 2330 → 2330 台積電；輸入 0050 → 0050 元大台灣50。','flow',['輸入代號／名稱','選擇自動完成','儲存統一名稱']);
  add('direction','交易方向','記錄這筆交易是做多還是做空，R 值會依此決定損益正負。',['單選，可留白；要計算 R 值時必須選擇。','Long（做多）：價格上升時，出場價高於入場價會算出正 R。','Short（做空）：價格下降時，出場價低於入場價會算出正 R。'],'同樣入場 100：做多出場 120 為獲利；做空出場 80 為獲利。','flow',['選做多／做空','比較進出價格','決定 R 正負']);
  add('timeframe','時間週期','記錄你判斷這筆交易時主要使用的圖表週期。',['單選，可留白。M 表示分鐘，H 表示小時。','1M、5M、15M：每根 K 棒分別代表 1、5、15 分鐘；1H、4H：每根代表 1、4 小時。','日線與週線：每根分別代表一天或一週。若參考多個週期，選主要週期，其他寫在依據補充。'],'主要依 15 分鐘圖表進場，就選「15M」。這不是持倉時間。','flow',['15 分鐘','一根 K 棒','主要觀察週期']);
  const prices={
    entry_price:['入場價格','實際進場成交的價格。','填數字，可含小數，不需輸入貨幣符號或千分位逗號。','例如實際成交 100，就填 100；這是 R 值的起點。'],
    stop_price:['止損價格','這筆交易用來衡量原始風險的止損價格。','做多止損須低於入場價；做空止損須高於入場價。相同價格無法計算風險。','做多入場 100、止損 90，價格風險為 10，也就是 1R。'],
    exit_price:['出場價格','實際平倉成交的價格，決定本筆已實現的價格變化。','尚未出場可先留白，R 值會等資料齊全才計算。','做多入場 100、止損 90、出場 120，損益為 +2R。'],
    target_price:['止盈價格','事先記錄的目標出場價格，用來回顧計畫。','填預定目標，可留白；本欄不參與實際 R 值計算。','目標 130，但實際出場 120：止盈填 130、出場填 120，R 依 120 計算。']
  };
  Object.entries(prices).forEach(([key,[title,intro,rule,example]])=>add(key,title,intro,['選填。所有價格請使用同一商品、相同單位。',rule,'目前每個欄位只記一個價格，不會自動彙整分批成交或換算幣別。'],example,'price',[title]));
  add('r_value','損益（R 值）','以入場與止損的價差作為 1R，衡量實際出場的損益倍數。',['自動計算，無需手動輸入。請先填方向、入場、止損及出場價格。','做多 R＝（出場－入場）÷（入場－止損）；做空 R＝（入場－出場）÷（止損－入場）。','正值表示獲利、負值表示虧損，0 表示進出價格相同；資料不齊或止損方向無效時留白。','只用價格計算，未含手續費、滑價、數量與分批成交；它不是實際金額報酬率。'],'做多：入場 100、止損 90、出場 120 → 20 ÷ 10＝+2R。做空：入場 100、止損 110、出場 80，也為 +2R。','price',['損益（R 值）']);
  add('followed_plan','按計畫執行','回顧實際執行是否符合事先訂下的交易計畫。',['單選，可留白。','「是」：主要進場、風險及出場規則均依計畫執行；「否」：有偏離。','此欄不由盈虧自動判斷。獲利也可能違反計畫，虧損也可能完全照計畫。'],'原定等回踩才進場，實際直接追價 → 選「否」，並在反思寫下原因。','flow',['原先計畫','對照實際','是／否']);
  add('trend','市場趨勢','記錄進場前，在所選時間週期看到的走勢狀態。',['單選，可留白。','上漲：你判斷走勢整體向上；下跌：整體向下；震盪：在區間內來回。','這是當時的觀察紀錄，不是系統行情判斷；可在進場依據補充判定方式。'],'你在主要圖表看到價格來回於同一區間，可選「震盪」。','flow',['觀察當時走勢','上漲／下跌／震盪','記錄判斷']);
  for(const side of ['support','resistance'])for(let n=1;n<=3;n++){
    const key=side+(n===1?'':'_'+n),label=side==='support'?'支撐':'壓力';
    add(key,`關鍵${label}位 ${n}`,`記錄第 ${n} 個你關注的${label}價位或區域。`,['選填，每格可單獨留白，不必把三格全部填滿。','可填單一價位，也可填文字區間；每格記錄一個價位或區域，三格不需按大小排序。',side==='support'?'支撐是你觀察到價格下跌時可能出現承接的位置；只記錄觀察，不保證會反彈。':'壓力是你觀察到價格上漲時可能受到阻力的位置；只記錄觀察，不保證會下跌。','這些欄位不參與 R 值計算，PDF 會保留已填價位及格次。'],side==='support'?'第 1 格填 95、第 2 格填 90～92；若只需第 3 格，也能單獨填入。':'第 1 格填 110、第 2 格填 118～120；沒有其他位置就留白。','level',[label,`第 ${n} 格`]);
  }
  add('entry_reasons','為什麼進場？','勾選當時真正促使你進場的理由。',['可複選，也可全部留白。勾選分類後，在「我的進場依據」寫下實際觸發條件。','趨勢交易：順著所觀察趨勢；支撐壓力：依關鍵區域；突破：穿越原有邊界；假突破：突破後又回到原區間。','回踩：突破後回到相關位置測試；型態：依圖表結構；基本面：依財務或經濟因素。','消息面：依事件資訊；量價：成交量與價格的配合；其它：不屬於前述分類，請補充。'],'當時因突破後回踩而進場，可勾「突破」「回踩」，再記下確認條件。','flow',['看到訊號','勾選理由','寫具體依據']);
  add('entry_basis','我的進場依據','用一句具體描述，留下當時做出進場決定的原因。',['選填，可換行，最多 12,000 字。','可以依序寫「觀察週期 → 價位或條件 → 觸發現象」。','描述當時確實看見的條件；較長內容在匯出 PDF 時會完整列到附頁。'],'例：15 分鐘圖突破區間後，回測 100 附近且收回區間上緣，因此進場。','flow',['觀察位置','觸發條件','進場決定']);
  add('stop_reasons','止損依據','記錄你設定止損價格時的依據。',['可複選、可留白；這裡記理由，實際價格填在「止損價格」。','前低 / 前高外側：依先前高低位置；ATR：依平均真實波幅衡量波動；結構失效：原先判斷的走勢結構不成立。','固定 %：依自行設定的百分比；其它：請在「其它依據補充」說明。','系統不會依勾選項目自動設定止損價格。'],'原計畫以先前低點外側作為失效位置，可勾「前低 / 前高外側」。','flow',['原始判斷','失效條件','填入止損價']);
  add('exit_reasons','出場依據','記錄這次實際出場的原因。',['可複選、可留白；實際成交價格另填在「出場價格」。','到目標：到達預定目標；到壓力 / 支撐：到達關注區域；訊號消失：原進場條件已不成立。','提前害怕：因擔心而提早出場；被止損：止損條件觸發；其它：補充其他原因。'],'未到原先目標，因擔心回吐而出場，可勾「提前害怕」，如實記錄即可。','flow',['持倉中變化','實際出場','勾選原因']);
  add('logic_notes','其它依據補充','補足勾選分類無法表達的進場、止損或出場細節。',['選填，可換行，最多 12,000 字。','可用「進場：」「止損：」「出場：」分段，對應勾選的其它項目。','此欄在 PDF 的補充頁完整呈現，原表會標示附頁位置。'],'例：出場：因預定收盤前平倉的時間條件到達。','flow',['選擇其它','補充情境','附頁完整保留']);
  const discipline={
    deviated:['有沒有偏離交易計畫？','比較事先計畫與實際行為，是否出現計畫外的調整。','原先只做已確認的訊號，實際卻因臨時想法進場 → 有。'],
    chased:['有沒有追高追空？','是否在價格快速移動後，因怕錯過而追著價格進場。','沒有等原定回測位置，因價格急漲就追入 → 有。'],
    early_entry:['有沒有提前進場（沒等確認）？','是否在原先要求的確認條件完成前就進場。','原定等 K 棒收盤確認，還未收盤已下單 → 有。'],
    moved_stop:['有沒有隨意移動止損？','是否在沒有預定規則的情況下更動止損位置。','因不想承認虧損而臨時放寬止損 → 有；依原定移動止損規則執行，不等同隨意移動。'],
    emotional:['有沒有因為情緒而交易？','是否因焦慮、興奮、憤怒或想翻本等情緒，做出原計畫之外的交易。','上一筆虧損後急著追回損失，沒有原定訊號仍進場 → 有。'],
    overtraded:['有沒有過度交易？','相對於你事先的次數、條件或風險限制，是否做了多餘交易。','自己原先限定三筆，第三筆之後仍無計畫加做 → 有。']
  };
  Object.entries(discipline).forEach(([key,[title,intro,example]])=>add(key,title,intro,['單選「有」或「沒有」，也可暫時留白。','依實際行為填寫，不以獲利或虧損作為判斷標準。','如選「有」，可在交易反思記下觸發原因與下次調整方式；系統不會自動替你評分。'],example,'flow',['回想實際行為','有／沒有','記下改善方式']));
  for(const [key,title,timing] of [['mood_before','進場前','下單之前'],['mood_after','結束後','結束這筆交易之後']])add(key,title,`記錄${timing}的心理狀態，方便日後比較情緒與行為。`,['每一列單選，可留白，兩列可以選不同狀態。','很好：感覺穩定且狀態佳；還好：大致平穩；普通：中性、沒有明顯起伏。','焦慮：擔心、緊張或怕錯過；煩躁 / 生氣：不耐煩、挫折或憤怒。','依自己的當下感受選擇；這是自我紀錄，並非心理診斷或系統評分。'],`${timing}若明顯擔心錯過行情，可以選「焦慮」。`,'mood',[title]);
  add('best','這筆交易做得最好的地方是什麼？','留下值得在下一筆重複的具體行為。',['選填，可換行，最多 12,000 字。','把行為與效果一起記錄，例如等待、執行、準備或紀律。','即使虧損，也能記錄做得好的部分；PDF 過長內容會移到附頁。'],'例：等到原定確認條件出現才進場，沒有因短線波動追價。','flow',['一個具體行為','帶來的效果','下次持續做']);
  add('improve','如果重來一次，我會改什麼？','把本次經驗轉成下一次可以執行的調整。',['選填，可換行，最多 12,000 字。','描述「哪個行為 → 怎麼調整」，避免只寫籠統的責備。','可對應交易紀律中選「有」的項目；PDF 會完整保留長文字。'],'例：這次在確認前進場；下次先把確認條件寫下，再檢查是否完成。','flow',['本次問題','可執行調整','下次檢查']);
  add('lessons','今天最大的收穫','為這筆交易的反思加上方便回顧的主題分類。',['可複選，也可留白；依你自己的反思勾選。','不要預測：注意臆測；只等確認：重視條件完成；突破後等回踩：記錄對回測的體會。','不追高追空：反思追價行為；固定止損：反思依原定止損規則執行；其它：在下方補充。','選項只記錄心得，不會更改交易條件或產生指令。'],'若這筆最大的體會是等待確認，可勾「只等確認」並補充具體經驗。','flow',['回顧一筆交易','勾選收穫','留下提醒']);
  add('lesson_notes','其它收穫補充','補充今天收穫的具體內容，或勾選「其它」後的說明。',['選填，可換行，最多 12,000 字。','可記下今天學到的事與下次會如何使用。','匯出時會放在 PDF 補充頁，原表會標示附頁位置。'],'例：事先把理由寫清楚，能讓我在回顧時分辨當時判斷與事後想法。','flow',['今天的體會','實際例子','下次提醒']);
  for(const [slot,title,tip] of [['entry','進場截圖','保留進場當時的圖表，可標示進場點、止損與當時依據。'],['exit','出場截圖','保留出場當時的圖表，可標示出場點與出場原因。'],['review','事後複盤截圖','保留交易結束後的回顧圖，可對照原計畫與後續走勢。']])add('image_'+slot,title,'上傳此階段的圖片，與本筆交易一起保存。',['選填，每一欄各一張。點選檔案或拖曳圖片至該欄。',tip,'支援 PNG、JPG、WebP、GIF，每張最多 10 MB；系統會檢查能否讀取圖片。','選取後可先看預覽，選新檔會取代該欄圖片；「移除圖片」的變更也要儲存交易才生效。','原始圖片會存入本機資料庫與日期資料夾；PDF 等比例放入對應框格，GIF 在 PDF 中使用首幀。'],'進場圖放「進場」、出場圖放「出場」、回顧圖放「事後複盤」；上傳後按「儲存交易」。','image',[title]);
  add('owner_name','姓名','設定本機交易手記的預設姓名，顯示於 PDF 抬頭。',['首次使用必填，1 至 30 字；不接受空白姓名或換行。','下次開啟自動使用，不需再次輸入。點右上角或表單抬頭的姓名可修改。','按「儲存姓名」立即更新本機資料庫及既有日期資料夾中的 PDF；取消則保留原名。','姓名屬於這套本機資料的共同設定，不是多使用者帳號，也不需密碼。'],'輸入「王小明」後，PDF 抬頭會顯示「王小明　一頁式交易日誌」。','flow',['輸入姓名','本機記住','PDF 顯示']);
  add('search','搜尋商品或流水號','快速查找已儲存的交易紀錄。',['輸入商品名稱的一部分，或完整／部分流水號，清空即可取消搜尋。','可與日期篩選一起使用，結果須同時符合兩個條件。','搜尋不會修改或刪除原有交易。'],'輸入「2303」尋找商品；輸入「TR-000001」尋找特定流水號。','flow',['名稱／流水號','符合條件','開啟交易']);
  add('date_filter','依日期篩選','只顯示某一個交易日期的紀錄。',['下拉選單列出目前已有紀錄的日期，括號是該日期的筆數。','選「所有日期」可取消日期限制；若仍有搜尋文字，搜尋條件會繼續生效。','只篩選顯示結果，不會變更交易日期或日期資料夾。'],'選擇 2026-09-20，只看該日紀錄；選「所有日期」恢復跨日期查看。','flow',['選擇日期','篩選紀錄','所有日期還原']);

  function illustration(item){
    let drawing='',caption='';
    if(item.kind==='price'){
      const highlight={'入場價格':100,'止損價格':145,'出場價格':55,'止盈價格':25,'損益（R 值）':100}[item.title];
      drawing=`<path d="M48 165V18M48 165H540" fill="none" stroke="#aac0cb"/><path d="M65 126L110 100L160 112L220 73L270 86L320 55L365 32" fill="none" stroke="#398e9c" stroke-width="3"/>${[[25,'目標 130'],[55,'出場 120'],[100,'入場 100'],[145,'止損 90']].map(([y,t])=>`<path d="M60 ${y}H400" stroke="${y===highlight?'#087f83':'#c0d1d9'}" stroke-dasharray="5 5"/><text x="425" y="${y+5}" fill="${y===highlight?'#087f83':'#445d70'}" font-weight="${y===highlight?'700':'400'}">${t}</text>`).join('')}<path d="M380 103V142M374 103H386M374 142H386" stroke="#b46962" stroke-width="2"/><text x="300" y="133" fill="#94524b">風險 1R</text>`;
      caption='做多價格示意：入場 100、止損 90、出場 120，價格風險 10，實際獲利 20＝2R；目標價另行記錄。';
    }else if(item.kind==='level'){
      const support=item.labels[0]==='支撐',y=support?139:40;
      drawing=`<path d="M40 164V20M40 164H550" fill="none" stroke="#aac0cb"/><path d="M55 100L110 42L168 135L228 54L293 136L350 42L415 100L480 60L530 120" fill="none" stroke="#6a93a8" stroke-width="3"/><rect x="48" y="${y-7}" width="494" height="14" fill="#087f8325"/><path d="M48 ${y}H542" stroke="#087f83" stroke-width="2" stroke-dasharray="6 4"/><rect x="300" y="${support?146:6}" width="238" height="27" rx="6" fill="#e3f1f2"/><text x="315" y="${support?165:25}" fill="#176a74">${escape(item.labels[0])}區域 · ${escape(item.labels[1])}可選填</text>`;
      caption=`示意圖中的水平帶代表一個${item.labels[0]}區域；不是即時行情或價格預測。三個欄位可分別記錄不同位置。`;
    }else if(item.kind==='mood'){
      drawing=['很好','還好','普通','焦慮','煩躁／生氣'].map((t,i)=>`<circle cx="${64+i*114}" cy="68" r="24" fill="${['#d5ece8','#e5f0e8','#e9edf2','#f8eed7','#f4e2df'][i]}" stroke="#a5bac5"/><text x="${64+i*114}" y="74" text-anchor="middle" fill="#35566a">${i+1}</text><text x="${64+i*114}" y="122" text-anchor="middle" fill="#35566a">${t}</text>`).join('');
      caption=`${item.title}這一列只選一個最接近的感受；數字只表示圖示順序，不是分數。`;
    }else if(item.kind==='image'){
      drawing=`<rect x="85" y="12" width="410" height="162" rx="10" fill="white" stroke="#abc1cd"/><rect x="85" y="12" width="410" height="27" rx="8" fill="#e2eef2"/><circle cx="105" cy="26" r="4" fill="#54959b"/><text x="123" y="31" fill="#476979">${escape(item.title)} · 圖片預覽</text><path d="M115 145L170 110L220 127L283 72L342 98L405 59L464 75" fill="none" stroke="#248794" stroke-width="3"/><circle cx="283" cy="72" r="6" fill="#dfad65"/><path d="M283 82V131" stroke="#8c7757"/><text x="239" y="153" fill="#526e7d">標示重點位置</text>`;
      caption='上傳你自己的圖表圖片並標示重點；這張圖僅示範畫面內容，不會寫入交易紀錄。';
    }else{
      drawing=item.labels.map((label,i)=>`<rect x="${15+i*194}" y="37" width="160" height="104" rx="12" fill="${i===1?'#dceef0':'#edf3f6'}" stroke="#c1d5de"/><circle cx="${95+i*194}" cy="65" r="15" fill="#287f8b"/><text x="${95+i*194}" y="71" text-anchor="middle" fill="white">${i+1}</text><text x="${95+i*194}" y="111" text-anchor="middle" fill="#285164">${escape(label)}</text>${i<2?`<path d="M${181+i*194} 88h20m-7-6 7 6-7 6" stroke="#4f8e9b" fill="none" stroke-width="2"/>`:''}`).join('');
      caption=item.labels.join(' → ')+'。';
    }
    return `<figure class="help-figure"><svg viewBox="0 0 580 186" role="img" aria-label="${escape(item.title+'填寫示意圖')}" xmlns="http://www.w3.org/2000/svg">${drawing}</svg><figcaption>${escape(caption)}</figcaption></figure>`;
  }
  const dialog=document.createElement('dialog');
  dialog.id='field-help-dialog';dialog.setAttribute('aria-labelledby','field-help-title');
  dialog.innerHTML='<header class="help-dialog-top"><span>欄位填寫指南</span><button type="button" class="help-close" aria-label="關閉欄位說明">×</button></header><div id="field-help-body"></div><footer><button type="button" class="primary help-done">了解，返回填寫</button></footer>';
  document.body.append(dialog);
  let opener;
  const close=()=>dialog.close();
  dialog.querySelector('.help-close').onclick=close;dialog.querySelector('.help-done').onclick=close;
  dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)close();}});
  dialog.addEventListener('close',()=>{if(opener?.isConnected)opener.focus({preventScroll:true});});
  function button(key){
    const item=entries[key];if(!item)throw new Error('Missing help: '+key);
    const b=document.createElement('button');b.type='button';b.className='field-help-button';b.dataset.help=key;
    b.textContent='說明';b.setAttribute('aria-label',item.title+'：圖文說明');b.setAttribute('aria-haspopup','dialog');b.title='查看'+item.title+'的圖文說明';
    b.onclick=e=>{e.preventDefault();e.stopPropagation();opener=b;
      document.getElementById('field-help-body').innerHTML=`<h2 id="field-help-title">${escape(item.title)}</h2><p class="help-intro">${escape(item.intro)}</p>${illustration(item)}<h3>如何填寫</h3><ul>${item.steps.map(s=>`<li>${escape(s)}</li>`).join('')}</ul><section class="help-example"><h3>填寫範例</h3><p>${escape(item.example)}</p></section>`;
      dialog.showModal();dialog.scrollTop=0;dialog.querySelector('.help-close').focus();
    };return b;
  }
  function attach(schema){
    for(const field of schema.flatMap(s=>s.fields)){
      if(document.querySelector(`[data-help="${field.key}"]`))continue;
      const input=document.querySelector(`#trade-form [name="${field.key}"]`);if(!input)continue;
      const b=button(field.key),level=input.closest('.paper-levels');
      if(level){const label=input.closest('label'),wrapper=document.createElement('div');wrapper.className='help-level';label.before(wrapper);wrapper.append(label,b);continue;}
      const mood=input.closest('.paper-mindset');
      if(mood){input.closest('tr').querySelector('th').append(b);continue;}
      const discipline=input.closest('.paper-discipline');
      if(discipline){discipline.querySelector('span').append(b);continue;}
      const label=input.id&&document.querySelector(`label[for="${input.id}"]`);
      if(label){label.after(b);continue;}
      const cell=input.closest('td');
      const title=cell.previousElementSibling?.tagName==='TH'?cell.previousElementSibling:cell.closest('tr').previousElementSibling?.querySelector('th');
      if(title)title.append(b);else input.closest('.paper-choices').after(b);
    }
    for(const slot of ['entry','exit','review']){const title=document.querySelector(`#upload-${slot} .upload-title`);if(title&&!title.querySelector('[data-help]'))title.append(button('image_'+slot));}
    if(!document.querySelector('[data-help="owner_name"]'))document.querySelector('label[for="owner-name"]').after(button('owner_name'));
    for(const [id,key,title] of [['search','search','搜尋商品或流水號'],['date-filter','date_filter','依日期篩選']]){
      const input=document.getElementById(id);if(!input||document.querySelector(`[data-help="${key}"]`))continue;
      const wrapper=document.createElement('div');wrapper.className='help-filter';input.before(wrapper);
      const label=document.createElement('label');label.htmlFor=id;label.textContent=title;const heading=document.createElement('div');heading.append(label,button(key));wrapper.append(heading,input);
    }
  }
  window.JournalHelp={attach};
})();
