"""Prepare PDF export dependencies locally without changing global packages."""
from pathlib import Path
import importlib.util
import subprocess
import sys
import urllib.request

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'vendor'))
try:
    import reportlab, pypdf
    from PIL import Image
except ImportError:
    packages = ['reportlab==4.4.9', 'pypdf==6.10.0', 'Pillow==12.3.0']
    if importlib.util.find_spec('pip'):
        installer = [sys.executable, '-m', 'pip']
    else:
        zipapp = ROOT / '.runtime' / 'pip.pyz'
        zipapp.parent.mkdir(exist_ok=True)
        urllib.request.urlretrieve('https://bootstrap.pypa.io/pip/pip.pyz', zipapp)
        installer = [sys.executable, str(zipapp)]
    subprocess.run(installer + ['install', '--disable-pip-version-check', '--target', str(ROOT / 'vendor'), *packages], check=True)
print('PDF export dependencies ready.')
