﻿param([switch]$NoBrowser, [switch]$RebuildExports)
$ErrorActionPreference = 'Stop'
$journalRoot = $PSScriptRoot
$journalUrl = 'http://127.0.0.1:33968/'
$journalData = Join-Path $journalRoot '資料'
$journalMutex = $null
$journalLocked = $false

function Get-JournalHealth {
    try {
        $result = Invoke-RestMethod -Uri ($journalUrl + 'api/health') -TimeoutSec 2
        if ($result.app -eq 'local-trading-journal' -and $result.data_dir -eq $journalData) { return $true }
    } catch { }
    return $false
}

function Test-JournalServerProcess($processInfo) {
    if (-not $processInfo -or -not $processInfo.CommandLine) { return $false }
    $expectedScript = Join-Path $journalRoot 'server.py'
    return ($processInfo.Name -in @('python.exe', 'pythonw.exe') -and
        $processInfo.CommandLine.IndexOf($expectedScript, [StringComparison]::OrdinalIgnoreCase) -ge 0)
}

function Stop-ExistingJournalService {
    $processIds = New-Object 'System.Collections.Generic.HashSet[int]'
    $pidFile = Join-Path $journalData 'service.pid'

    if (Test-Path -LiteralPath $pidFile -PathType Leaf) {
        $savedPid = 0
        if ([int]::TryParse((Get-Content -LiteralPath $pidFile -Raw).Trim(), [ref]$savedPid)) {
            $processInfo = Get-CimInstance Win32_Process -Filter "ProcessId=$savedPid" -ErrorAction SilentlyContinue
            if (Test-JournalServerProcess $processInfo) { [void]$processIds.Add($savedPid) }
        }
    }

    # The PID file can be stale or missing, so also find this exact server.py path.
    foreach ($processInfo in @(Get-CimInstance Win32_Process -Filter "Name='python.exe' OR Name='pythonw.exe'" -ErrorAction SilentlyContinue)) {
        if (Test-JournalServerProcess $processInfo) { [void]$processIds.Add([int]$processInfo.ProcessId) }
    }

    foreach ($serverPid in $processIds) {
        Stop-Process -Id $serverPid -Force -ErrorAction Stop
        try { Wait-Process -Id $serverPid -Timeout 5 -ErrorAction Stop } catch {
            if (Get-Process -Id $serverPid -ErrorAction SilentlyContinue) {
                throw "無法關閉舊的交易手記服務（PID $serverPid）。"
            }
        }
    }
    Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue

    for ($attempt = 0; $attempt -lt 20; $attempt++) {
        if (-not (Get-JournalHealth)) { return }
        Start-Sleep -Milliseconds 250
    }
    if (Get-JournalHealth) { throw '舊的交易手記服務仍在執行，無法重新啟動。' }
}

function Test-JournalPython([string]$candidate) {
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $false }
    try {
        $result = & $candidate -c 'import sys, sqlite3, http.server; print(''JOURNAL_OK'' if sys.version_info >= (3,10) else ''OLD'')' 2>$null
        return ($LASTEXITCODE -eq 0 -and $result -eq 'JOURNAL_OK')
    } catch { return $false }
}

try {
    $rootHash = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($journalRoot))).Replace('-','').Substring(0,20)
    $journalMutex = New-Object Threading.Mutex($false, ('Local\TradingJournal-' + $rootHash))
    $journalLocked = $journalMutex.WaitOne(60000)
    if (-not $journalLocked) { throw '另一個啟動程序正在準備中，請稍後再試。' }
    if ($RebuildExports -and (Get-JournalHealth)) { throw '請先關閉本機服務或重新開機，在啟動交易手記前執行重建。' }
    if (-not $RebuildExports) { Stop-ExistingJournalService }
    if ($RebuildExports -or -not (Get-JournalHealth)) {
        $candidates = @((Join-Path $journalRoot '.runtime/python.exe'))
        foreach ($command in @(Get-Command python.exe,python3.exe -ErrorAction SilentlyContinue)) {
            if ($command.Source -notlike '*\Microsoft\WindowsApps\*') { $candidates += $command.Source }
        }
        $candidates += Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
        $candidates += @(Get-ChildItem -Path (Join-Path $env:LOCALAPPDATA 'Programs/Python/Python*/python.exe') -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
        $journalPython = $null
        foreach ($candidate in $candidates) {
            if (Test-JournalPython $candidate) { $journalPython = $candidate; break }
        }
        if (-not $journalPython) {
            $runtimeDir = Join-Path $journalRoot '.runtime'
            New-Item -ItemType Directory -Path $runtimeDir -Force | Out-Null
            $runtimeZip = Join-Path $runtimeDir 'python.zip'
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            if ([Environment]::Is64BitOperatingSystem) {
                $runtimeUrl = 'https://www.python.org/ftp/python/3.13.12/python-3.13.12-embed-amd64.zip'
                $runtimeHash = '76f238f606250c87c6beac75dccd35ee99070a13490555936abb6cb64ecce3d0'
            } else {
                $runtimeUrl = 'https://www.python.org/ftp/python/3.13.12/python-3.13.12-embed-win32.zip'
                $runtimeHash = '51ec4c741212f9488d678033bd2c8a67fc27cf7d36abffee7cb9f4481c9fb52b'
            }
            Invoke-WebRequest -Uri $runtimeUrl -OutFile $runtimeZip -UseBasicParsing -TimeoutSec 180
            if ((Get-FileHash -LiteralPath $runtimeZip -Algorithm SHA256).Hash -ne $runtimeHash) {
                throw '安裝檔驗證失敗，請重新執行一鍵啟動。'
            }
            Expand-Archive -LiteralPath $runtimeZip -DestinationPath $runtimeDir -Force
            Remove-Item -LiteralPath $runtimeZip
            $journalPython = Join-Path $runtimeDir 'python.exe'
            if (-not (Test-JournalPython $journalPython)) { throw '本機執行環境安裝失敗。' }
        }
        & $journalPython (Join-Path $journalRoot 'ensure_dependencies.py')
        if ($LASTEXITCODE -ne 0) { throw 'PDF 匯出所需元件安裝失敗，請確認網路後重新啟動。' }
        if ($RebuildExports) {
            & $journalPython (Join-Path $journalRoot 'rebuild_exports.py')
            if ($LASTEXITCODE -ne 0) { throw '重建日期資料夾失敗。' }
            exit 0
        }
        New-Item -ItemType Directory -Path $journalData -Force | Out-Null
        $journalScript = Join-Path $journalRoot 'server.py'
        $journalProcess = Start-Process -FilePath $journalPython -ArgumentList ('"' + $journalScript + '"') -WorkingDirectory $journalRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $journalData '啟動.log') -RedirectStandardError (Join-Path $journalData '錯誤.log') -PassThru
        $ready = $false
        for ($attempt = 0; $attempt -lt 40; $attempt++) {
            if (Get-JournalHealth) { $ready = $true; break }
            $journalProcess.Refresh()
            if ($journalProcess.HasExited) { break }
            Start-Sleep -Milliseconds 250
        }
        if (-not $ready) { throw '無法啟動交易手記。請確認 33968 連接埠沒有被其他程式占用，並查看資料資料夾內的錯誤.log。' }
        Set-Content -LiteralPath (Join-Path $journalData 'service.pid') -Value $journalProcess.Id -Encoding ASCII
    }
    if (-not $NoBrowser) { Start-Process -FilePath $journalUrl }
    Write-Output 'Trading Journal is ready: http://127.0.0.1:33968/'
} catch {
    New-Item -ItemType Directory -Path $journalData -Force | Out-Null
    $_ | Out-String | Set-Content -LiteralPath (Join-Path $journalData '啟動失敗.txt') -Encoding UTF8
    if (-not $NoBrowser) {
        Add-Type -AssemblyName PresentationFramework
        [System.Windows.MessageBox]::Show($_.Exception.Message, '交易手記') | Out-Null
    }
    Write-Error $_
    exit 1
} finally {
    if ($journalLocked) { $journalMutex.ReleaseMutex() }
    if ($journalMutex) { $journalMutex.Dispose() }
}
