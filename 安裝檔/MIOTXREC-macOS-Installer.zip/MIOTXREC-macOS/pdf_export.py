"""Fill the original, unchanged PDF artwork and append overflow without data loss."""
from io import BytesIO
from pathlib import Path
import threading

from PIL import Image, ImageOps
from pypdf import PdfReader, PdfWriter
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parent
TEMPLATE = ROOT / '交易記錄表 繁體中文.pdf'
FONT = 'JournalCJK'
FONT_LOCK = threading.Lock()
INK = HexColor('#143b51')

def ensure_font():
    with FONT_LOCK:
        if FONT not in pdfmetrics.getRegisteredFontNames():
            candidates = [
                Path('/System/Library/Fonts/PingFang.ttc'),
                Path('/System/Library/Fonts/STHeiti Light.ttc'),
                Path('/System/Library/Fonts/Supplemental/Songti.ttc'),
                Path('/Library/Fonts/Arial Unicode.ttf'),
            ]
            failures = []
            for font_path in candidates:
                if not font_path.is_file():
                    continue
                try:
                    pdfmetrics.registerFont(TTFont(FONT, str(font_path), subfontIndex=0))
                    return
                except Exception as exc:
                    failures.append(f'{font_path}: {exc}')
            detail = '; '.join(failures) if failures else '找不到可用字型檔'
            raise RuntimeError(f'無法載入繁體中文字型：{detail}')

def wrap(text, width, size):
    lines = []
    for paragraph in str(text).replace('\r\n', '\n').replace('\r', '\n').split('\n'):
        line = ''
        for char in paragraph:
            if line and pdfmetrics.stringWidth(line + char, FONT, size) > width:
                lines.append(line)
                line = char
            else:
                line += char
        lines.append(line)
    return lines

def render_pdf(record, images):
    ensure_font()
    source = PdfReader(str(TEMPLATE))
    page = source.pages[0]
    width, height = float(page.mediabox.width), float(page.mediabox.height)
    stream = BytesIO()
    c = canvas.Canvas(stream, pagesize=(width, height))
    c.setFillColor(INK)
    c.setStrokeColor(INK)
    d = record['data']
    overflow = []

    def line(text, x, top, size=7.5):
        c.setFont(FONT, size)
        c.setFillColor(INK)
        c.drawString(x, height - top - size, str(text))

    def box(text, x, top, w, h, label, size=8):
        if text is None or text == '':
            return
        text = str(text)
        chosen, lines = size, []
        while chosen >= min(6, size):
            lines = wrap(text, w, chosen)
            if len(lines) * chosen * 1.16 <= h:
                break
            chosen -= .5
        else:
            overflow.append((label, text))
            lines = [f'詳見附頁 {len(overflow)}']
            chosen = 6.5
        offset = max(0, (h - len(lines) * chosen * 1.16) / 2)
        for i, value in enumerate(lines):
            line(value, x, top + offset + i * chosen * 1.16, chosen)

    def check(x, top, size=6.8):
        c.setStrokeColor(INK)
        c.setLineWidth(1.05)
        path = c.beginPath()
        path.moveTo(x + .9, height - top - size * .5)
        path.lineTo(x + size * .4, height - top - size + 1)
        path.lineTo(x + size - .7, height - top - 1)
        c.drawPath(path)

    def choices(key, options, xs, top, size=6.8):
        selected = d.get(key, [])
        if not isinstance(selected, list):
            selected = [selected]
        for value, x in zip(options, xs):
            if value in selected:
                check(x, top, size)

    # All coordinates refer to the original A4 artwork, measured from the top.
    name = record.get('owner_name', '')
    if name:
        size = min(7.5, 190 / max(1, pdfmetrics.stringWidth(name, FONT, 1)))
        c.setFont(FONT, size)
        c.setFillColor(INK)
        c.drawRightString(341, height - 39.3, name)
    meta = f"{record['serial']}   填表 {record['started_at'].replace('T', ' ')}   儲存 {record['created_at'].replace('T', ' ')}"
    box(meta, 34, 43.3, 527, 6.6, '填表資訊', 5.5)
    box(d.get('trade_date'), 101, 100, 192, 14.5, '日期')
    box(d.get('product'), 364.6, 100, 192, 14.5, '商品')
    choices('direction', ['Long（做多）', 'Short（做空）'], [103, 181], 122.4)
    choices('timeframe', ['1M','5M','15M','1H','4H','日線','週線'], [364.6,392.2,419.7,447.2,474.7,502.2,529.8], 122.4)
    for key, x in [('entry_price',83),('stop_price',214.8),('exit_price',346.6),('target_price',478.5)]:
        box(d.get(key), x, 135, 78.5, 14.5, key)
    box(d.get('r_value'), 101, 152.5, 245, 14.5, '損益 R 值')
    choices('followed_plan', ['是','否'], [424.4,461.4], 157.4)
    choices('trend', ['上漲','下跌','震盪'], [105,165,225], 194.4)
    for key, x, label in [('support',101,'關鍵支撐位'),('resistance',364.6,'關鍵壓力位')]:
        values = [d.get(key,''), d.get(key+'_2',''), d.get(key+'_3','')]
        text = '　'.join(f'{i+1}: {value}' for i,value in enumerate(values) if value != '')
        box(text, x, 207, 192, 17.5, label, 7.5)
    choices('entry_reasons', ['趨勢交易','支撐壓力','突破','假突破','回踩','型態','基本面','消息面','量價','其它'], [39,90.7,142.5,194.2,245.9,297.6,349.4,401.1,452.8,504.5], 263.4)
    box(d.get('entry_basis'), 190, 275, 367, 15, '我的進場依據', 7.5)
    choices('stop_reasons', ['前低 / 前高外側','ATR','結構失效','固定 %','其它'], [39,142.5,245.9,349.4,452.8], 307.3)
    choices('exit_reasons', ['到目標','到壓力 / 支撐','訊號消失','提前害怕','被止損','其它'], [39,125.2,211.4,297.6,383.9,470.1], 331.3)
    if d.get('logic_notes'):
        overflow.append(('其它依據補充', d['logic_notes']))
        line(f'其它依據：詳見附頁 {len(overflow)}', 360, 293.2, 6)
    for i, key in enumerate(['deviated','chased','early_entry','moved_stop','emotional','overtraded']):
        xs = [245.6,285.6] if i % 2 == 0 else [509.3,549.3]
        choices(key, ['有','沒有'], xs, 365 + (i // 2) * 17.5, 6.5)
    moods = ['很好','還好','普通','焦慮','煩躁 / 生氣']
    choices('mood_before', moods, [146.4,237.9,329.3,420.8,512.2], 448.7, 6.6)
    choices('mood_after', moods, [146.4,237.9,329.3,420.8,512.2], 464.2, 6.6)
    box(d.get('best'), 147, 506, 410, 15, '這筆交易做得最好的地方', 7.5)
    box(d.get('improve'), 134, 524, 423, 15, '如果重來一次，我會改什麼', 7.5)
    choices('lessons', ['不要預測','只等確認','突破後等回踩','不追高追空','固定止損','其它'], [131,189,247,329,401,459], 547.4, 6.2)
    if d.get('lesson_notes'):
        overflow.append(('其它收穫補充',d['lesson_notes']))
        line(f'詳見附頁 {len(overflow)}', 490, 546.3, 5.8)
    for i, slot in enumerate(['entry','exit','review']):
        image = images.get(slot)
        if not image:
            continue
        x = 39 + i * (527.2756 / 3)
        try:
            with Image.open(BytesIO(image['data'])) as original:
                original.seek(0)
                pic = ImageOps.exif_transpose(original).convert('RGBA')
                picture = ImageReader(pic)
                iw, ih = pic.size
                scale = min(165.7 / iw, 196 / ih)
                w, h = iw * scale, ih * scale
                c.drawImage(picture, x + (165.7-w)/2, height-598-h, w, h, mask='auto')
        except (OSError, ValueError, Image.DecompressionBombError):
            raise ValueError('截圖無法匯出至 PDF，請重新上傳有效圖片。') from None
        # Full original filename is also in the database; fit without overlap.
        box(image['name'], x, 795, 165.7, 9.5, f'{slot}截圖檔名', 6)
    footer = f"{record['serial']}   更新 {record['updated_at'].replace('T',' ')}   填表耗時 {record['duration_seconds']} 秒"
    line(footer,34,807.8,5.5)
    c.showPage()

    if overflow:
        top = 70
        appendix_page = 0
        def appendix_header():
            nonlocal appendix_page
            appendix_page += 1
            line('交易記錄表 - 補充內容',34,27,16)
            line(f"{record['serial']}   {record['trade_date']}   附頁 {appendix_page}",34,51,8)
            c.setStrokeColor(HexColor('#a1b3c0'))
            c.line(34,height-65,561,height-65)
        appendix_header()
        for index,(label,text) in enumerate(overflow,1):
            if top > 755:
                c.showPage(); appendix_header(); top=76
            line(f'{index}. {label}',34,top,9)
            top += 18
            for value in wrap(text,519,9):
                if top > 787:
                    c.showPage(); appendix_header(); top=76
                line(value,38,top,9)
                top += 13
            top += 14
        c.showPage()
    c.save()
    overlay = PdfReader(BytesIO(stream.getvalue()))
    writer = PdfWriter()
    writer.add_page(page)
    writer.pages[0].merge_page(overlay.pages[0])
    for extra in overlay.pages[1:]:
        writer.add_page(extra)
    writer.add_metadata({'/Title': f"{record['serial']} 交易記錄表", '/Author':name or '交易手記'})
    output = BytesIO()
    writer.write(output)
    return output.getvalue()
