#!/bin/zsh
set -u

ROOT="$(cd "$(dirname "$0")" && pwd)"
DATA="$ROOT/資料"
SERVER="$ROOT/server.py"
URL="http://127.0.0.1:33968/"
PID_FILE="$DATA/service.pid"
LOCK_DIR="$DATA/.launch-lock"
START_LOG="$DATA/啟動.log"
ERROR_LOG="$DATA/錯誤.log"
mkdir -p "$DATA"

show_error() {
  local message="$1"
  printf '%s\n' "$message" >> "$ERROR_LOG"
  /usr/bin/osascript -e "display dialog \"$message\" with title \"交易手記\" buttons {\"好\"} default button \"好\" with icon stop" >/dev/null 2>&1 || true
  exit 1
}

find_python() {
  local candidate
  for candidate in "$(command -v python3 2>/dev/null || true)" /opt/homebrew/bin/python3 /usr/local/bin/python3; do
    if [[ -n "$candidate" && -x "$candidate" ]] && "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  return 1
}

if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  lock_pid="$(cat "$LOCK_DIR/pid" 2>/dev/null || true)"
  if [[ "$lock_pid" == <-> ]] && kill -0 "$lock_pid" 2>/dev/null; then
    show_error "另一個啟動程序正在準備中，請稍後再試。"
  fi
  rm -f "$LOCK_DIR/pid"
  rmdir "$LOCK_DIR" 2>/dev/null || show_error "無法清除上次未完成的啟動鎖定。"
  mkdir "$LOCK_DIR" || show_error "無法建立啟動鎖定。"
fi
printf '%s' "$$" > "$LOCK_DIR/pid"
trap 'rm -f "$LOCK_DIR/pid"; rmdir "$LOCK_DIR" 2>/dev/null || true' EXIT

PYTHON="$(find_python || true)"
if [[ -z "$PYTHON" ]]; then
  /usr/bin/open 'https://www.python.org/downloads/macos/' >/dev/null 2>&1 || true
  show_error "需要 Python 3.10 以上版本。已為你開啟 Python 官方下載頁，安裝完成後請再次執行一鍵啟動。"
fi

stop_if_ours() {
  local old_pid="$1"
  local command_line
  [[ "$old_pid" == <-> ]] || return 0
  command_line="$(ps -p "$old_pid" -o command= 2>/dev/null || true)"
  [[ "$command_line" == *"$SERVER"* ]] || return 0
  kill "$old_pid" 2>/dev/null || true
  for _ in {1..20}; do
    kill -0 "$old_pid" 2>/dev/null || return 0
    sleep 0.25
  done
  kill -9 "$old_pid" 2>/dev/null || true
}

if [[ -f "$PID_FILE" ]]; then
  stop_if_ours "$(tr -d '[:space:]' < "$PID_FILE")"
fi
if command -v lsof >/dev/null 2>&1; then
  for old_pid in $(lsof -nP -tiTCP:33968 -sTCP:LISTEN 2>/dev/null); do
    stop_if_ours "$old_pid"
  done
fi
rm -f "$PID_FILE"

printf '\n[%s] Preparing dependencies with %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$PYTHON" >> "$START_LOG"
"$PYTHON" "$ROOT/ensure_dependencies.py" >> "$START_LOG" 2>> "$ERROR_LOG" || show_error "PDF 元件安裝失敗。請確認網路後重新啟動，詳細內容請查看「資料/錯誤.log」。"

nohup "$PYTHON" "$SERVER" >> "$START_LOG" 2>> "$ERROR_LOG" </dev/null &
new_pid=$!
printf '%s\n' "$new_pid" > "$PID_FILE"

ready=0
for _ in {1..60}; do
  if JOURNAL_DATA="$DATA" "$PYTHON" -c 'import json,os,urllib.request; result=json.load(urllib.request.urlopen("http://127.0.0.1:33968/api/health",timeout=1)); raise SystemExit(0 if result.get("app")=="local-trading-journal" and os.path.realpath(result.get("data_dir",""))==os.path.realpath(os.environ["JOURNAL_DATA"]) else 1)' 2>/dev/null; then
    ready=1
    break
  fi
  kill -0 "$new_pid" 2>/dev/null || break
  sleep 0.25
done

if [[ "$ready" -ne 1 ]]; then
  rm -f "$PID_FILE"
  show_error "無法啟動交易手記。請確認 33968 連接埠未被其他程式使用，並查看「資料/錯誤.log」。"
fi

/usr/bin/open "$URL" || show_error "服務已啟動，但無法開啟瀏覽器。請手動開啟 $URL"
printf '交易手記已啟動：%s\n' "$URL"
