#!/bin/zsh
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
PYTHON="$(command -v python3 2>/dev/null || true)"
if [[ -z "$PYTHON" ]] || ! "$PYTHON" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null; then
  /usr/bin/osascript -e 'display dialog "需要 Python 3.10 以上版本。" with title "交易手記" buttons {"好"} default button "好" with icon stop' >/dev/null 2>&1 || true
  exit 1
fi
"$ROOT/停止服務.command"
"$PYTHON" "$ROOT/ensure_dependencies.py" || exit 1
"$PYTHON" "$ROOT/rebuild_exports.py" || exit 1
/usr/bin/osascript -e 'display notification "日期資料夾重建完成" with title "交易手記"' >/dev/null 2>&1 || true
printf '日期資料夾重建完成。\n'
