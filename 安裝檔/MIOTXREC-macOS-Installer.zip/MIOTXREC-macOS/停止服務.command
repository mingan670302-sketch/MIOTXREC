#!/bin/zsh
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$ROOT/資料/service.pid"
SERVER="$ROOT/server.py"

if [[ -f "$PID_FILE" ]]; then
  old_pid="$(tr -d '[:space:]' < "$PID_FILE")"
  if [[ "$old_pid" == <-> ]]; then
    command_line="$(ps -p "$old_pid" -o command= 2>/dev/null || true)"
    if [[ "$command_line" == *"$SERVER"* ]]; then
      kill "$old_pid" 2>/dev/null || true
      for _ in {1..20}; do
        kill -0 "$old_pid" 2>/dev/null || break
        sleep 0.25
      done
    fi
  fi
fi
rm -f "$PID_FILE"
/usr/bin/osascript -e 'display notification "本機服務已停止" with title "交易手記"' >/dev/null 2>&1 || true
printf '交易手記服務已停止。\n'
